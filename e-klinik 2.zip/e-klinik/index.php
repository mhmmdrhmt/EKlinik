<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="refresh" content="0;url=pages/login.php">
	<meta name="description" content="E-KLINIK">
	<title>E-KLINIK</title>
	<script language="javascript">
		window.location.href = "pages/login.php"
	</script>
</head>
<body>
	<a href="pages/login.php">Go to Demo</a>
</body>
</html>
