 <?php 
 $row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
 ?>
 <div class="sidebar-brand d-md-flex">
  <h2 style="color: white;"><img style="width: 60px;" src="assets/img/<?= $row_pengaturan['logo']; ?>">E-KLINIK</h2>
</div>
<br>
<ul class="sidebar-nav" data-coreui="navigation" data-simplebar="">
  <center style="background-color: gray;">
    <?php 
    if ($_SESSION['photo']=="" AND $_SESSION['id_jk']==1) {
     ?>
     <img src="assets/img/male.png" width="100"><br>
     <span class="badge bg-info"><?= $_SESSION['nama']; ?></span>
   <?php }elseif($_SESSION['photo']=="" AND $_SESSION['id_jk']==2){ ?>
    <img src="assets/img/female.png" width="100"><br>
    <span class="badge bg-info"><?= $_SESSION['nama']; ?></span>
  <?php }else{ ?>
    <img src="assets/img/<?= $_SESSION['photo']; ?>" style="border-radius: 15px;" width="100"><br>
    <span class="badge bg-info"><?= $_SESSION['nama']; ?></span>
  <?php } ?>
</center>
<center><li class="nav-title">Menu</li></center>
<li class="nav-item"><a class="nav-link" href="index.php">
  <svg class="nav-icon">
    <img src="https://cdn-icons-png.flaticon.com/512/4725/4725681.png" style="width: 30px;">
  </svg>Dashboard</a>
</li>
<li class="nav-item"><a class="nav-link" href="data-pasien.php">
  <svg class="nav-icon">
    <img src="https://cdn-icons-png.flaticon.com/512/4200/4200528.png" style="width: 30px;">
  </svg> Data Pasien</a>
</li>
<li class="nav-item"><a class="nav-link" href="data-rekam-medis.php">
  <svg class="nav-icon">
    <img src="https://cdn-icons-png.flaticon.com/512/2382/2382656.png" style="width: 30px;">
  </svg> Data Rekam Medis</a>
</li>
<li class="nav-item"><a class="nav-link" href="data-obat.php">
  <svg class="nav-icon">
    <img src="https://cdn-icons-png.flaticon.com/512/2968/2968933.png" style="width: 30px;">
  </svg> Master Data Obat</a>
</li>
<li class="nav-item"><a class="nav-link" href="grafik.php">
  <svg class="nav-icon">
    <img src="assets/img/grafik.png" style="width: 30px;">
  </svg> Grafik</a>
</li>
<li class="nav-item"><a class="nav-link" href="user.php">
  <svg class="nav-icon">
    <img src="https://cdn-icons-png.flaticon.com/512/476/476863.png" style="width: 30px;">
  </svg> User/Pengguna</a>
</li>
<li class="nav-item"><a class="nav-link" href="pengaturan.php">
  <svg class="nav-icon">
    <img src="https://cdn-icons-png.flaticon.com/512/738/738853.png" style="width: 30px;">
  </svg> Pengaturan</a>
</li>
<li class="nav-item"><a class="nav-link" onclick="return confirm('Ingin Keluar ?')" href="logout.php">
  <svg class="nav-icon">
    <img src="https://cdn-icons-png.flaticon.com/512/1828/1828490.png" style="width: 30px;">
  </svg> Keluar</a>
</li>
</div>
<div class="wrapper d-flex flex-column min-vh-100 bg-light">
  <header class="header header-sticky mb-4">
    <div class="container-fluid">
      <button class="header-toggler px-md-0 me-md-3" type="button" onclick="coreui.Sidebar.getInstance(document.querySelector('#sidebar')).toggle()">
        <svg class="icon icon-lg">
          <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-menu"></use>
        </svg>
      </button>

      <ul class="header-nav ms-3">
        <li class="nav-item dropdown"><a class="nav-link py-0" data-coreui-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
          <div class="avatar avatar-md">
            <?php 
            if ($_SESSION['photo']=="" AND $_SESSION['id_jk']==1) {
             ?>
             <img class="avatar-img" src="assets/img/male.png" alt="<?= $_SESSION['username']; ?>">
           <?php }elseif($_SESSION['photo']=="" AND $_SESSION['id_jk']==2){ ?>
            <img class="avatar-img" src="assets/img/female.png" alt="<?= $_SESSION['username']; ?>">
          <?php }else{ ?>
            <img class="avatar-img" src="assets/img/<?= $_SESSION['photo']; ?>" style="border-radius: 15px;" alt="<?= $_SESSION['username']; ?>">
          <?php } ?>
        </div>
      </a>
      <div class="dropdown-menu dropdown-menu-end pt-0">
        <div class="dropdown-header bg-light py-2">
          <div class="fw-semibold">Account</div>
        </div>
        <a class="dropdown-item" href="profil.php">
          <svg class="icon me-2">
            <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-user"></use>
          </svg> Profile
        </a>
        <div class="dropdown-divider"></div>
        <a class="dropdown-item" href="logout.php" onclick="return confirm('Ingin keluar dari aplikasi ?')">
          <svg class="icon me-2">
            <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-account-logout"></use>
          </svg> Keluar
        </a>
      </div>
    </li>
  </ul>