<footer class="footer">
    <div>© 2022 E-KLINIK</div>
    <!-- <div class="ms-auto">Powered by&nbsp;<a href="https://coreui.io/docs/">CoreUI UI Components</a></div> -->
</footer>