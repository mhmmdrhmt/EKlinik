<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
function formatTanggal($date){
 // ubah string menjadi format tanggal
  return date('d-M-Y', strtotime($date));
}
$thn=date('Y');
if (isset($_POST['filter'])) {
  $bln=$_POST['bln'];
}else{
  $bln=date('m');
}
if ($bln=='01') {
  $nama_bln='Januari';
}elseif ($bln=='02') {
  $nama_bln='Februari';
}elseif ($bln=='03') {
  $nama_bln='Maret';
}elseif ($bln=='04') {
  $nama_bln='April';
}elseif ($bln=='05') {
  $nama_bln='Mei';
}elseif ($bln=='06') {
  $nama_bln='Juni';
}elseif ($bln=='07') {
  $nama_bln='Juli';
}elseif ($bln=='08') {
  $nama_bln='Agustus';
}elseif ($bln=='09') {
  $nama_bln='September';
}elseif ($bln=='10') {
  $nama_bln='Oktober';
}elseif ($bln=='11') {
  $nama_bln='November';
}elseif ($bln=='12') {
  $nama_bln='Desember';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- <base href="./../"> -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/<?= $row_pengaturan['logo']; ?>">
  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap4.min.css">

  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
    <link rel="canonical" href="https://coreui.io/docs/content/tables/">
    <link rel="stylesheet" type="text/css" href="../apexcharts/dist/apexcharts.css">
  </head>
  <body>
    <div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
      <?php 
      require_once"template/menu.php";
      ?>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb my-0 ms-2">
          <li class="breadcrumb-item">
            <a style="text-decoration: none;" href="index.php">Home</a>
          </li>
          <li class="breadcrumb-item active">
            <span>Grafik</span>
          </li>
          <li class="breadcrumb-item active"><span style="color: black;"><?= date('d-M-Y'); ?></span></li>
        </ol>
      </nav>
    </div>
  </header>
  <div class="body flex-grow-1 px-3" style="background-color: #06d6a0;"><br>
    <div class="container-lg">
      <div class="card mb-4">
        <div class="card-header">
          <strong>Grafik Diagnosa Bulan <?= $nama_bln; ?> <?= $thn; ?>
          <form action="" method="post">
            <select name="bln" required>
              <option value="">--Bulan--</option>
              <option value="01">Januari</option>
              <option value="02">Februari</option>
              <option value="03">Maret</option>
              <option value="04">April</option>
              <option value="05">Mei</option>
              <option value="06">Juni</option>
              <option value="07">Juli</option>
              <option value="08">Agustus</option>
              <option value="09">September</option>
              <option value="10">Oktober</option>
              <option value="11">November</option>
              <option value="12">Desember</option>
            </select>
            <input type="submit" name="filter" value="filter">
          </form>
        </strong>
      </div>
      <div class="card-body">
        <div id="chart-coba">
        </div>
          <!-- <hr>
          <div id="chart-coba">
          </div> -->
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah Data User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="post" enctype="multipart/form-data">
        <div class="modal-body">
          <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" placeholder="Nama" class="form-control form-control-sm is-valid" required>
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Username" class="form-control form-control-sm is-valid" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukan Password" class="form-control form-control-sm is-valid" required>
          </div>
          <div class="form-group">
            <label>Jenis Kelamin</label>
            <select class="form-control form-control-sm is-valid" name="id_jk" required>
              <option value="">--Pilih--</option>
              <option value="1">Laki-laki</option>
              <option value="2">Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="Email aktif" class="form-control form-control-sm is-valid">
          </div>
          <div class="form-group">
            <label>No Telp</label>
            <input type="number" maxlength="12" minlength="12" name="no_telp" placeholder="No Telp" class="form-control form-control-sm is-valid" required>
          </div>  
          <div class="form-group">
            <label>Foto (Jika ada)</label>
            <input type="file" name="photo" class="form-control form-control-sm is-valid">
          </div>  
        </div>
        <div class="modal-footer">
          <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
<script src="vendors/simplebar/js/simplebar.min.js"></script>
<script type="text/javascript" src="../apexcharts/dist/apexcharts.js"></script>
<script type="text/javascript" src="../apexcharts/dist/apexcharts.min.js"></script>
<script type="text/javascript">
  var options = {
    series: [
    <?php 
    $diag=mysqli_query($koneksi,"SELECT DISTINCT diagnosa FROM tbl_rekam_medis WHERE bln='$bln' AND thn='$thn'");
    while ($t_diagnosa=mysqli_fetch_array($diag)) {
      $diagnosa=$t_diagnosa['diagnosa'];
      ?>
      {
        name: '<?= $diagnosa; ?>',
        data: [
        <?php 
        $hasil=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tbl_rekam_medis WHERE diagnosa='$diagnosa' AND bln='$bln' AND thn='$thn'"));
        ?>
        <?= $hasil; ?>,
        ]
      },
    <?php } ?>
    ],
    chart: {
      type: 'bar',
      height: 350
    },
    plotOptions: {
      bar: {
        horizontal: false,
        columnWidth: '20%',
        endingShape: 'rounded'
      },
    },
    dataLabels: {
      enabled: true
    },
    stroke: {
      show: true,
      width: 2,
      colors: ['transparent']
    },
    xaxis: {
      categories: ['<?= $nama_bln; ?> <?= $thn; ?>'],
    },
    yaxis: {
      title: {
        text: '(org)'
      }
    },
    fill: {
      opacity: 1
    },
    tooltip: {
      y: {
        formatter: function (val) {
          return " " + val + " Org"
        }
      }
    }
  };

  var chart = new ApexCharts(document.querySelector("#chart"), options);
  chart.render();
</script>

<script type="text/javascript">
  document.addEventListener("DOMContentLoaded", function () {
    window.ApexCharts && (new ApexCharts(document.getElementById('chart-coba'), {
      series: [{
        data: [
        <?php 
        $diag=mysqli_query($koneksi,"SELECT DISTINCT diagnosa FROM tbl_rekam_medis WHERE bln='$bln' AND thn='$thn'");
        while ($t_diagnosa=mysqli_fetch_array($diag)) {
          $diagnosa=$t_diagnosa['diagnosa'];
          ?>
          <?php 
          $a=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tbl_rekam_medis WHERE diagnosa='$diagnosa' AND bln='$bln' AND thn='$thn'"));
          ?>
          <?= $a; ?>,

        <?php } ?>
        ]
      }],
      chart: {
        type: 'bar',
        height: 390
      },
      plotOptions: {
        bar: {
          barHeight: '70%',
          distributed: true,
          horizontal: true,
          dataLabels: {
            position: 'bottom'
          },
        }
      },
      colors: ['#33b2df', '#546E7A', '#d4526e', '#13d8aa', '#A5978B', '#2b908f', '#f9a3a4', '#90ee7e',
      '#f48024', '#69d2e7'
      ],
      dataLabels: {
        enabled: true,
        textAnchor: 'start',
        style: {
          colors: ['#fff']
        },
        formatter: function (val, opt) {
          return opt.w.globals.labels[opt.dataPointIndex] + ":  " + val
        },
        offsetX: 0,
        dropShadow: {
          enabled: true
        }
      },
      stroke: {
        width: 1,
        colors: ['#fff']
      },
      xaxis: {
        categories: [
        <?php 
        $diag=mysqli_query($koneksi,"SELECT DISTINCT diagnosa FROM tbl_rekam_medis WHERE bln='$bln' AND thn='$thn'");
        while ($t_diagnosa=mysqli_fetch_array($diag)) {
          $diagnosa=$t_diagnosa['diagnosa'];
          ?>
          '<?= $diagnosa; ?>',
        <?php } ?>
        ],
      },
      yaxis: {
        labels: {
          show: false
        }
      },
      title: {
        text: 'Grafik Diagnosa <?= $nama_bln; ?> <?= $thn; ?>',
        align: 'center',
        floating: true
      },
      subtitle: {
        text: '',
        align: 'center',
      },
      tooltip: {
        theme: 'dark',
        x: {
          show: false
        },
        y: {
          title: {
            formatter: function () {
              return ''
            }
          }
        }
      }

    })).render();
  });
</script>
</body>
</html>