<?php 
session_start();
$id_user=$_SESSION['id_user'];
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
date_default_timezone_set("Asia/Jakarta");
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));

$a=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tbl_rekam_medis"));
$b=$a+1;
$bln=date('m');
$thn=date('Y');
$huruf="PPM";
$kode_rm="$b/$huruf/$bln/$thn";
// --------------
function formatTanggal($date){
 // ubah string menjadi format tanggal
 return date('d-M-Y', strtotime($date));
}
function rupiah($angka){
  $hasil_rupiah = "Rp. " . number_format($angka, 0, ".", ".");
  return $hasil_rupiah;
}
// Simpan data
if (isset($_POST['simpan'])) {
  $tgl_periksa=mysqli_real_escape_string($koneksi, $_POST['tgl_periksa']);
  $kode_rm=mysqli_real_escape_string($koneksi, $_POST['kode_rm']);
  $bln= date('m', strtotime($tgl_periksa));
  $thn= date('Y', strtotime($tgl_periksa));
  $id_pasien=mysqli_real_escape_string($koneksi, $_POST['id_pasien']);
  $keluhan=mysqli_real_escape_string($koneksi, $_POST['keluhan']);
  $pemeriksaan_fisik=mysqli_real_escape_string($koneksi, $_POST['pemeriksaan_fisik']);
  $diagnosa=mysqli_real_escape_string($koneksi, $_POST['diagnosa']);
  $terapi=mysqli_real_escape_string($koneksi, $_POST['terapi']);
  $biaya_periksa=mysqli_real_escape_string($koneksi, $_POST['biaya_periksa']);
  $b=mysqli_real_escape_string($koneksi, $_POST['biaya']);
  $biaya = preg_replace("/[^0-9]/", "", $b);
  $input=mysqli_query($koneksi,"INSERT INTO tbl_rekam_medis VALUES(NULL,'$kode_rm','$id_user','$tgl_periksa','$bln','$thn','$id_pasien','$keluhan','$pemeriksaan_fisik','$diagnosa','$terapi','$biaya_periksa','$biaya')");
  if ($input>0) {
    echo "<script>window.alert('data rekam medis behasil ditambahkan')
    window.location='data-rekam-medis.php'</script>";
  }else{
    echo "<script>window.alert('data rekam medis gagal ditambahkan !!!')
    window.location='data-rekam-medis.php'</script>";
  }
}
// hapus data
if (isset($_GET['aksi'])=='del') {
  $id_rekam_medis=mysqli_real_escape_string($koneksi, $_GET['aqsw']);
  $hapus=mysqli_query($koneksi,"DELETE FROM tbl_rekam_medis WHERE id_rekam_medis='$id_rekam_medis'");
  if ($hapus>0) {
    echo "<script>window.alert('data rekam medis behasil dihapus')
    window.location='data-rekam-medis.php'</script>";
  }else{
    echo "<script>window.alert('data rekam gagal dihapus !!!')
    window.location='data-rekam-medis.php'</script>";
  }
}
if (isset($_GET['del'])) {
  $id=mysqli_real_escape_string($koneksi, $_GET['del']);
  $qa=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM rekam_medis_obat 
    INNER JOIN tbl_rekam_medis ON rekam_medis_obat.id_rekam_medis=tbl_rekam_medis.id_rekam_medis
    INNER JOIN tbl_obat ON rekam_medis_obat.id_obat=tbl_obat.id_obat WHERE id='$id'"));
  $id_ob=$qa['id_obat'];
  $stok_obat=$qa['stok_obat'];
  $stok_keluar=$qa['stok_keluar'];
  $hg_obat=$qa['harga'];
  $hj_obat=$qa['harga_jual'];
  $profit=$qa['profit'];
  $jml=$qa['jml'];
  $jikaxy=$hj_obat-$hg_obat;
  $makaxy=$jikaxy*$jml;
  // ruumus
  $hasil_stok_obat=$stok_obat+$jml;
  $hasil_stok_keluar=$stok_keluar-$jml;
  $hasil_profit=$profit-$makaxy;
  // 
  mysqli_query($koneksi,"UPDATE tbl_obat SET stok_obat='$hasil_stok_obat', stok_keluar='$hasil_stok_keluar', profit='$hasil_profit' WHERE id_obat='$id_ob'");
  $hapus=mysqli_query($koneksi,"DELETE FROM rekam_medis_obat WHERE id='$id'");
  echo "<script>window.alert('Obat dihapus dari rekam medis')
  window.location='data-rekam-medis.php'</script>";
}
if (isset($_POST['simpan_obat'])) {
  $id_obat = $_POST['id_obat'];
  $id_rekam_medis=$_POST['id_rekam_medis'];
  $stok_obat = $_POST['stok_obat'];
  $stok_keluar = $_POST['stok_keluar'];
  $harga = $_POST['harga'];
  $profit = $_POST['profit'];
  $harga_jual = $_POST['harga_jual'];
  $jml_obat = $_POST['jml_obat'];
  $jumlah_dipilih = count($id_obat);
  for($j=0;$j<$jumlah_dipilih;$j++){
    if ($jml_obat[$j]=="" OR $jml_obat[$j]==0) {
      $jml_obat[$j]=0;
    }else{
      $jml_obat[$j];
    }
    if ($jml_obat[$j]!==0) {
      $hasil=$stok_obat[$j]-$jml_obat[$j];
      $h_stok_keluar=$stok_keluar[$j]+$jml_obat[$j];
      // Profit
      $ab=$harga_jual[$j]-$harga[$j];
      $h_profit=$jml_obat[$j]*$ab;
      $ok_profit=$profit[$j]+$h_profit;
      // 
      $a=mysqli_query($koneksi,"INSERT INTO rekam_medis_obat VALUES(NULL,'$id_rekam_medis','$jml_obat[$j]','$id_obat[$j]')");
      $b=mysqli_query($koneksi,"UPDATE tbl_obat SET stok_obat='$hasil', stok_keluar='$h_stok_keluar', profit='$ok_profit' WHERE id_obat='$id_obat[$j]'");
    }
  }
  echo "<script>window.alert('Obat Berhasil ditambahkan')
  window.location='data-rekam-medis.php'</script>";  
}
if (isset($_POST['edit'])) {
  $id_rekam_medis=mysqli_real_escape_string($koneksi, $_POST['id_rekam_medis']);
  $keluhan=mysqli_real_escape_string($koneksi, $_POST['keluhan']);
  $pemeriksaan_fisik=mysqli_real_escape_string($koneksi, $_POST['pemeriksaan_fisik']);
  $diagnosa=mysqli_real_escape_string($koneksi, $_POST['diagnosa']);
  $terapi=mysqli_real_escape_string($koneksi, $_POST['terapi']);
  $biaya_periksa=mysqli_real_escape_string($koneksi, $_POST['biaya_periksa']);
  $b=mysqli_real_escape_string($koneksi, $_POST['biaya']);
  $biaya = preg_replace("/[^0-9]/", "", $b);
  $update=mysqli_query($koneksi,"UPDATE tbl_rekam_medis SET keluhan='$keluhan', pemeriksaan_fisik='$pemeriksaan_fisik', diagnosa='$diagnosa', terapi='$terapi', biaya_periksa='$biaya_periksa', biaya='$biaya' WHERE id_rekam_medis='$id_rekam_medis'");
  if ($update) {
    echo "<script>window.alert('Rekam Medis Berhasil diupdate')
    window.location='data-rekam-medis.php'</script>";  
  }else{
    echo "<script>window.alert('Gagal diupdate')
    window.location='data-rekam-medis.php'</script>";  
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- <base href="./../"> -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <script type="text/javascript" src="../ckeditor/ckeditor.js"></script>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/<?= $row_pengaturan['logo']; ?>">
  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->

  <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap4.min.css">

  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/css/selectize.bootstrap3.min.css" integrity="sha256-ze/OEYGcFbPRmvCnrSeKbRTtjG4vGLHXgOqsyLFTRjg=" crossorigin="anonymous" />
  
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
    <link rel="canonical" href="https://coreui.io/docs/content/tables/">
  </head>
  <body>
    <div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
      <?php 
      require_once"template/menu.php";
      ?>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb my-0 ms-2">
          <li class="breadcrumb-item">
            <a style="text-decoration: none;" href="index.php">Home</a>
          </li>
          <li class="breadcrumb-item active">
            <span>Data Rekam Medis</span>
          </li>
          <li class="breadcrumb-item active"><span style="color: black;"><?= date('d-M-Y'); ?></span></li>
        </ol>
      </nav>
    </div>
  </header>
  <div class="body flex-grow-1 px-3" style="background-color: #06d6a0;">
    <br>
    <div class="container-lg">
      <div class="card mb-4">
        <div class="card-header">
          <strong>Data Rekam Medis</strong>
        </div>
        <div class="card-body">
          <a href="#" style="font-size: 10pt;" class="btn btn-info text-white" data-toggle="modal" data-target="#tambahData">
            <img src="https://cdn-icons-png.flaticon.com/512/863/863782.png" style="width: 20px;"> Tambah Data</a>
            <!-- <a href="" style="font-size: 10pt;" class="btn btn-primary" data-toggle="modal" data-target="#cetakData">
              <img src="https://cdn-icons-png.flaticon.com/512/3233/3233446.png" style="width: 20px;"> Cetak Data</a> -->
              <div class="example">
                <div class="tab-content rounded-bottom">
                  <div class="tab-pane p-3 active preview" role="tabpanel" id="preview-877">
                    <table style="font-size: 10pt;" id="example" class="table table-responsive">
                      <thead>
                        <tr>
                          <th>NO</th>
                          <th scope="col">OPSI</th>
                          <th scope="col">KODE REKAM MEDIS</th>
                          <th scope="col">PETUGAS KLINIK</th>
                          <th scope="col">TGL PERIKSA</th>
                          <th scope="col">NAMA PASIEN</th>
                          <th scope="col">KELUHAN</th>
                          <th scope="col">PEMERIKSAAN FISIK</th>
                          <th scope="col">DIAGNOSA</th>
                          <th scope="col">TERAPI</th>
                          <th scope="col">BIAYA PERIKSA LAB</th>
                          <th scope="col">BIAYA PEMERIKSAAN</th>
                          <th>OBAT</th>
                          <th>TOTAL</th>
                        </tr>
                      </thead>
                      <?php
                      $no=1;
                      $rekam_medis=mysqli_query($koneksi,"SELECT * FROM tbl_rekam_medis
                        INNER JOIN user ON tbl_rekam_medis.id_user=user.id_user
                        INNER JOIN tbl_pasien ON tbl_rekam_medis.id_pasien=tbl_pasien.id_pasien ORDER BY tgl_periksa DESC");
                      while ($row_rekam_medis=mysqli_fetch_array($rekam_medis)) {
                        ?>
                        <div class="modal fade" id="edit<?= $row_rekam_medis['id_rekam_medis']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                          <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                              <form action="" method="post">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalLabel">Edit Rekam Medis <?= $row_rekam_medis['kode_rm']; ?> <br><?= $row_rekam_medis['nama_pasien']; ?> <?= $row_rekam_medis['tgl_periksa']; ?></h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <div class="form-group">
                                    <label for="exampleInputEmail1">Keluhan</label>
                                    <input type="hidden" name="id_rekam_medis" value="<?= $row_rekam_medis['id_rekam_medis']; ?>">
                                    <textarea class="form-control" name="keluhan"><?= $row_rekam_medis['keluhan']; ?></textarea>
                                  </div>
                                  <div class="form-group">
                                    <label>Pemeriksaan Fisik</label>
                                    <textarea class="ckeditor" id="ckeditor" name="pemeriksaan_fisik" required>
                                      <?= $row_rekam_medis['pemeriksaan_fisik']; ?>
                                    </textarea>
                                  </div>
                                  <div class="form-group">
                                    <label for="exampleInputEmail1">Diagnosa</label>
                                    <textarea class="form-control" name="diagnosa"><?= $row_rekam_medis['diagnosa']; ?></textarea>
                                  </div>
                                  <div class="form-group">
                                    <label for="exampleInputEmail1">Terapi</label>
                                    <textarea class="form-control" name="terapi"><?= $row_rekam_medis['terapi']; ?></textarea>
                                  </div>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1">Biaya Periksa Lab Dasar Rp.</span>
                                    </div>
                                    <input type="text" autocomplete="off" value="<?= $row_rekam_medis['biaya_periksa']; ?>" class="form-control" name="biaya_periksa" id="masking3" placeholder="Biaya Periksa Lab Dasar" aria-label="Biaya Pemeriksaan" aria-describedby="basic-addon1">
                                  </div>
                                  <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                      <span class="input-group-text" id="basic-addon1">Biaya Pemeriksaan Rp.</span>
                                    </div>
                                    <input type="text" autocomplete="off" value="<?= $row_rekam_medis['biaya']; ?>" class="form-control" name="biaya" id="masking4" placeholder="Biaya Pemeriksaan" aria-label="Biaya Pemeriksaan" aria-describedby="basic-addon1">
                                  </div>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">tutup</button>
                                  <button type="submit" name="edit" class="btn btn-info">Save</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>

                        <tr>
                          <td><?= $no++; ?>.</td>
                          <td>     
                            <table cellpadding="0" border="0" cellspacing="0">
                              <tr>
                                <td>
                                  <a href="data-rekam-medis.php?aksi=del&aqsw=<?= $row_rekam_medis['id_rekam_medis']; ?>" onclick="return confirm('Ingin hapus data ini ?')"><img src="https://cdn-icons-png.flaticon.com/512/5028/5028066.png" style="width: 30px;"></a>
                                </td>
                                <td>
                                  <a href="#" data-toggle="modal" data-target="#edit<?= $row_rekam_medis['id_rekam_medis']; ?>"><img src="https://cdn-icons-png.flaticon.com/512/5996/5996831.png" width="30"></a>
                                </td>
                              </tr>
                              <tr>
                                <td>
                                  <a href="print.php?qaz=<?= $row_rekam_medis['id_rekam_medis']; ?>" target="_blank"><img src="https://cdn-icons-png.flaticon.com/512/3209/3209265.png" width="30"></a>
                                </td>
                                <td>
                                  <a href="" data-toggle="modal" data-target="#<?= $row_rekam_medis['id_rekam_medis']; ?>"><img src="https://cdn-icons-png.flaticon.com/512/822/822143.png" width="30"></a>
                                  <div class="modal fade" id="<?= $row_rekam_medis['id_rekam_medis']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-lg" role="document">
                                      <div class="modal-content">
                                        <form action="" method="post">
                                          <div class="modal-header bg-info text-white">
                                            <h5 class="modal-title" id="exampleModalLongTitle">Obat Rekam Medis <br><?= $row_rekam_medis['nama_pasien']; ?> <?= $row_rekam_medis['tgl_periksa']; ?> </h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                              <span aria-hidden="true">&times;</span>
                                            </button>
                                          </div>
                                          <div class="modal-body">
                                            <table class="table" id="example2">
                                             <thead>
                                              <tr>
                                                <th>#</th>
                                                <th>Nama Obat</th>
                                                <th>Jml</th>
                                                <th>Jenis Obat</th>
                                                <th>Harga</th>
                                              </tr>
                                            </thead>
                                            <?php 
                                            $no_urut=1;
                                            $data_obat=mysqli_query($koneksi,"SELECT * FROM tbl_obat");
                                            while ($row_obat=mysqli_fetch_array($data_obat)) {
                                              ?>
                                              <tr>
                                                <td>
                                                  <input type="hidden" name="id_rekam_medis" value="<?= $row_rekam_medis['id_rekam_medis']; ?>">
                                                  <input type="hidden" name="stok_obat[]" value="<?= $row_obat['stok_obat']; ?>">
                                                  <input type="hidden" name="id_obat[]" value="<?= $row_obat['id_obat']; ?>">
                                                  <input type="hidden" name="stok_keluar[]" value="<?= $row_obat['stok_keluar']; ?>">
                                                  <input type="hidden" name="harga[]" value="<?= $row_obat['harga']; ?>">
                                                  <input type="hidden" name="harga_jual[]" value="<?= $row_obat['harga_jual']; ?>">
                                                  <input type="hidden" name="profit[]" value="<?= $row_obat['profit']; ?>">
                                                  <?= $no_urut++; ?>
                                                </td>
                                                <td><?= $row_obat['nama_obat']; ?></td>
                                                <td>
                                                  <input type="number" min="0" max="<?= $row_obat['stok_obat']; ?>" name="jml_obat[]" value="0" class="form-control">
                                                </td>
                                                <td><?= $row_obat['jenis_obat']; ?></td>
                                                <td><span class="badge bg-info" style="font-size: 11pt;"><?= rupiah($row_obat['harga_jual']); ?></span></td>
                                              </tr>
                                            <?php } ?>
                                          </table>
                                        </div>
                                        <div class="modal-footer">
                                          <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                          <button type="submit" name="simpan_obat" class="btn btn-info">Submit</button>
                                        </div>
                                      </form>
                                    </div>
                                  </div>
                                </div>
                              </td>
                            </tr>
                          </table>  
                        </td>
                        <td><span class="badge bg-light text-dark" style="font-size: 10pt;"><?= $row_rekam_medis['kode_rm']; ?></span></td>
                        <td><span class="badge bg-light text-dark" style="font-size: 10pt;"><?= $row_rekam_medis['nama']; ?></span></td>
                        <td><span style="font-size: 10pt;" class="badge bg-light text-dark"><?= $row_rekam_medis['tgl_periksa']; ?></span></td>
                        <td><span class="badge bg-light text-dark" style="font-size: 10pt;"><?= $row_rekam_medis['nama_pasien']; ?></span></td>
                        <td><?= $row_rekam_medis['keluhan']; ?></td>
                        <td>
                          <a href="#" data-toggle="modal" data-target="#<?= $row_rekam_medis['id_rekam_medis'] ?>qwe"><span style="font-size: 12pt;" class="badge bg-info">Lihat</span></a>
                          <div class="modal fade" id="<?= $row_rekam_medis['id_rekam_medis'] ?>qwe" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                              <div class="modal-content">
                                <div class="modal-header">
                                  <h5 class="modal-title" id="exampleModalLongTitle">Pemeriksaan Fisik <br><?= $row_rekam_medis['nama_pasien']; ?> <?= $row_rekam_medis['tgl_periksa']; ?></h5>
                                  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                  </button>
                                </div>
                                <div class="modal-body">
                                  <?= $row_rekam_medis['pemeriksaan_fisik']; ?>
                                </div>
                                <div class="modal-footer">
                                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </td>
                        <td><?= $row_rekam_medis['diagnosa']; ?></td>
                        <td><?= $row_rekam_medis['terapi']; ?></td>
                        <td>
                          <span style="font-size: 10pt;" class="badge bg-info"><?= rupiah($row_rekam_medis['biaya_periksa']); ?></span>
                        </td>
                        <td>
                          <span style="font-size: 10pt;" class="badge bg-info"><?= rupiah($row_rekam_medis['biaya']); ?></span>
                        </td>
                        <td>
                          <?php 
                          $id_rekam_medis=$row_rekam_medis['id_rekam_medis'];
                          $daftar_obat=mysqli_query($koneksi,"SELECT * FROM rekam_medis_obat INNER JOIN tbl_obat ON rekam_medis_obat.id_obat=tbl_obat.id_obat WHERE id_rekam_medis='$id_rekam_medis'");
                          while ($t=mysqli_fetch_array($daftar_obat)) {
                            ?>
                            <span class="badge bg-light" style="font-size: 12pt; color: black;">
                              <a href="data-rekam-medis.php?del=<?= $t['id']; ?>" onclick="return confirm('hapus obat <?= $t['nama_obat']; ?> - <?= $t['jenis_obat']; ?> ?')" style="text-decoration: none;">
                                <img src="https://cdn-icons-png.flaticon.com/512/1632/1632600.png" style="width: 15px;">
                              </a>
                              <?= $t['nama_obat']; ?> <?= $t['jenis_obat']; ?> (Qty <?= $t['jml']; ?>) 
                              <?php 
                              $h_jum=$t['jml']*$t['harga_jual'];
                              echo rupiah($h_jum);
                              ?>
                            </span>
                          <?php } ?>
                        </td>
                        <td>
                          <?php 
                          $result = mysqli_query($koneksi, "SELECT SUM(tbl_obat.harga_jual*rekam_medis_obat.jml) AS total_sum FROM rekam_medis_obat INNER JOIN tbl_obat ON rekam_medis_obat.id_obat=tbl_obat.id_obat WHERE rekam_medis_obat.id_rekam_medis='$id_rekam_medis'"); 
                          $row = mysqli_fetch_assoc($result); 
                          $sum = $row['total_sum'];
                          $biaya_p=$row_rekam_medis['biaya_periksa'];
                          $biaya_q=$row_rekam_medis['biaya'];
                          $hasil=$sum+$biaya_p+$biaya_q;
                          ?>
                          <span style="font-size: 12pt;" class="badge bg-primary"><?= rupiah($hasil); ?></span>
                        </td>
                      </tr>
                    <?php } ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah Data Rekam Medis</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Kode Rekam Medis</label>
            <input type="text" name="kode_rm" value="<?= $kode_rm; ?>" class="form-control" required>
          </div>
          <div class="form-group">
            <label>Pasien</label>
            <select id="select-state" name="id_pasien" required>
              <option value="">--Pilih--</option>
              <?php 
              $tgl_hari_ini=date('Y-m-d');
              $pasien=mysqli_query($koneksi,"SELECT * FROM tbl_pasien ORDER BY tgl_terdaftar DESC");
              $sum_pasien=mysqli_num_rows($pasien);
              while ($row_pasien=mysqli_fetch_array($pasien)) {
                ?>  
                <option value="<?= $row_pasien['id_pasien']; ?>"><?= $row_pasien['nama_pasien']; ?></option>              
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label>Tanggal periksa</label>
            <input type="datetime-local" value="<?= date('Y-m-d H:i:s'); ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Tanggal periksa" name="tgl_periksa" required>
          </div>
          <div class="form-group">
            <label>Keluhan</label>
            <textarea class="form-control form-control-sm is-valid" name="keluhan" required></textarea>
          </div>
          <div class="form-group">
            <label>Pemeriksaan Fisik</label>
            <textarea class="ckeditor" id="ckeditor" name="pemeriksaan_fisik" required>
              <table border="1" cellpadding="5" cellspacing="0" width="100%">
                <tr>
                  <td style="width: 200px;"><b>TEKANAN DARAH</b></td>
                  <td style="width: 400px;"> </td>
                </tr>
                <tr>
                  <td><b>NADI</b></td>
                  <td> </td>
                </tr>
                <tr>
                  <td><b>RESPIRASI</b></td>
                  <td> </td>
                </tr>
                <tr>
                  <td><b>SUHU</b></td>
                  <td></td>
                </tr>
                <tr>
                  <td><b>BERAT BADAN</b></td>
                  <td></td>
                </tr>
                <tr>
                  <td><b>GDS/GDP</b></td>
                  <td></td>
                </tr>
                <tr>
                  <td><b>ASAM URAT</b></td>
                  <td></td>
                </tr>
                <tr>
                  <td><b>KOLESTROL</b></td>
                  <td> </td>
                </tr>
                <tr>
                  <td><b>HB</b></td>
                  <td> </td>
                </tr>
              </table>
            </textarea>
          </div>
          <div class="form-group">
            <label>Diagnosa</label>
            <textarea class="form-control form-control-sm" name="diagnosa"></textarea>
          </div>
          <div class="form-group">
            <label>Terapi</label>
            <textarea class="form-control form-control-sm" name="terapi"></textarea>
          </div>
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1">Biaya Periksa Lab Dasar Rp.</span>
            </div>
            <input type="text" autocomplete="off" value="0" class="form-control" name="biaya_periksa" id="masking2" placeholder="Biaya Periksa Lab Dasar" aria-label="Biaya Pemeriksaan" aria-describedby="basic-addon1">
          </div>
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text" id="basic-addon1">Biaya Pemeriksaan Rp.</span>
            </div>
            <input type="text" autocomplete="off" value="0" class="form-control" name="biaya" id="masking1" placeholder="Biaya Pemeriksaan" aria-label="Biaya Pemeriksaan" aria-describedby="basic-addon1">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="cetakData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Cetak Data Pasien</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="cetak-rekam-medis.php" target="_blank" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Dari Tanggal</label>
            <input type="datetime-local" value="<?= date('Y-m-d H:i:s'); ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Dari Tanggal" name="dari_tgl" required>
          </div>
          <div class="form-group">
            <label>Sampai Tanggal</label>
            <input type="datetime-local" value="<?= date('Y-m-d H:i:s'); ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Sampai Tanggal" name="sampai_tgl" required>
          </div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
          <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
<script src="vendors/simplebar/js/simplebar.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable();
  } );
</script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example2').DataTable();
  } );
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $('#masking1').mask('#.##0', {reverse: true});
    $('#masking2').mask('#.##0', {reverse: true});
    $('#masking3').mask('#.##0', {reverse: true});
    $('#masking4').mask('#.##0', {reverse: true});
    $('#masking5').mask('#,##0.00', {reverse: true});
  })
</script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.6/js/standalone/selectize.min.js" integrity="sha256-+C0A5Ilqmu4QcSPxrlGpaZxJ04VjsRjKu+G82kl5UJk=" crossorigin="anonymous"></script>

<script type="text/javascript">
  $(document).ready(function () {
    $('select').selectize({
      sortField: 'text'
    });
  });
</script>
</body>
</html>