<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
// Simpan data
if (isset($_POST['simpan'])) {
  $copyright=mysqli_real_escape_string($koneksi, $_POST['copyright']);
  $ekstensi_diperbolehkan = array('png','jpg','JPG','PNG','jpeg','JPEG');
  $logo = $_FILES['logo']['name'];
  if ($logo!="") {
    $x = explode('.', $logo);
    $ekstensi = strtolower(end($x));
    $ukuran = $_FILES['logo']['size'];
    $file_tmp = $_FILES['logo']['tmp_name'];     
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
      if($ukuran <= 5000000){         
        move_uploaded_file($file_tmp, 'assets/img/'.$logo);
      }else{
        echo "<script>window.alert('Ukuran File Foto melebihi batas !!!')
        window.location='pengaturan.php'</script>";
      }
    }else{
      echo "<script>window.alert('ekstensi file tidak di perbolehkan !!!')
      window.location='pengaturan.php'</script>";
    }
  }else{
    $logo="";
  }
  $bg_login = $_FILES['bg_login']['name'];
  if ($bg_login!="") {
    $x = explode('.', $bg_login);
    $ekstensi = strtolower(end($x));
    $ukuran = $_FILES['bg_login']['size'];
    $file_tmp = $_FILES['bg_login']['tmp_name'];     
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
      if($ukuran <= 5000000){         
        move_uploaded_file($file_tmp, 'assets/img/'.$bg_login);
      }else{
        echo "<script>window.alert('Ukuran File Foto melebihi batas !!!')
        window.location='pengaturan.php'</script>";
      }
    }else{
      echo "<script>window.alert('ekstensi file tidak di perbolehkan !!!')
      window.location='pengaturan.php'</script>";
    }
  }else{
    $bg_login="";
  }
  $slide = $_FILES['slide']['name'];
  if ($slide!="") {
    $x = explode('.', $slide);
    $ekstensi = strtolower(end($x));
    $ukuran = $_FILES['slide']['size'];
    $file_tmp = $_FILES['slide']['tmp_name'];     
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
      if($ukuran <= 5000000){         
        move_uploaded_file($file_tmp, 'assets/img/'.$slide);
      }else{
        echo "<script>window.alert('Ukuran File Foto melebihi batas !!!')
        window.location='user'</script>";
      }
    }else{
      echo "<script>window.alert('ekstensi file tidak di perbolehkan !!!')
      window.location='user'</script>";
    }
  }else{
    $slide="";
  }
  if ($logo=="") {
    $update=mysqli_query($koneksi,"UPDATE pengaturan SET copyright='$copyright' WHERE id_pengaturan=1 ");
  }else{
    $update=mysqli_query($koneksi,"UPDATE pengaturan SET copyright='$copyright', logo='$logo' WHERE id_pengaturan=1 ");
  }
  if ($bg_login=="") {
    $update=mysqli_query($koneksi,"UPDATE pengaturan SET copyright='$copyright' WHERE id_pengaturan=1 ");
  }else{
    $update=mysqli_query($koneksi,"UPDATE pengaturan SET copyright='$copyright', bg_login='$bg_login' WHERE id_pengaturan=1 ");
  }
  if ($slide=="") {
    $update=mysqli_query($koneksi,"UPDATE pengaturan SET copyright='$copyright' WHERE id_pengaturan=1 ");
  }else{
    $update=mysqli_query($koneksi,"UPDATE pengaturan SET copyright='$copyright', slide='$slide' WHERE id_pengaturan=1 ");
  }
  if ($update) {
    echo "<script>window.alert('Pengaturan behasil diupdate')
    window.location='pengaturan.php'</script>";
  }else{
    echo "<script>window.alert('pengaturan gagal diupdate !!!')
    window.location='pengaturan.php'</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- <base href="./../"> -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/<?= $row_pengaturan['logo']; ?>">
  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap4.min.css">

  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
    <link rel="canonical" href="https://coreui.io/docs/content/tables/">
  </head>
  <body>
    <div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
      <?php 
      require_once"template/menu.php";
      ?>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb my-0 ms-2">
          <li class="breadcrumb-item">
            <a style="text-decoration: none;" href="index.php">Home</a>
          </li>
          <li class="breadcrumb-item active">
            <span>Pengaturan</span>
          </li>
        </ol>
      </nav>
    </div>
  </header>
  <div class="body flex-grow-1 px-3" style="background-color: #06d6a0;"><br>
    <div class="container-lg">
      <div class="card mb-4">
        <div class="card-header">
          <strong>Pengaturan</strong>
        </div>
        <div class="card-body">
          <form action="" method="post" enctype="multipart/form-data">
            <div class="row">
              <div class="col-lg-6">
                <div class="form-group">
                  <label>Logo</label><br>
                  <img src="assets/img/<?= $row_pengaturan['logo']; ?>" width="80">
                  <input type="file" accept="image/*" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Dari Tanggal" name="logo">
                </div>
                <div class="form-group">
                  <label>Background Login</label><br>
                  <img src="assets/img/<?= $row_pengaturan['bg_login']; ?>" width="200">
                  <input type="file" accept="image/*" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Dari Tanggal" name="bg_login">
                </div>
                <div class="form-group">
                  <label>Gambar Slide Dashboard</label><br>
                  <img src="assets/img/<?= $row_pengaturan['slide']; ?>" width="200">
                  <input type="file" accept="image/*" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Dari Tanggal" name="slide">
                </div>
                <div class="form-group">
                  <label>Copyright</label>
                  <input type="text" value="<?= $row_pengaturan['copyright']; ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Copyright" name="copyright">
                </div>
                <div class="form-group">
                  <input type="submit" class="btn btn-primary" name="simpan" value="Update">
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>



<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
<script src="vendors/simplebar/js/simplebar.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable();
  } );
</script>
</body>
</html>