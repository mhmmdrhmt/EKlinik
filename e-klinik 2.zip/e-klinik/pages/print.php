<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
function formatTanggal($date){
 // ubah string menjadi format tanggal
 return date('d-M-Y', strtotime($date));
}
function rupiah($angka){
  $hasil_rupiah = "Rp. " . number_format($angka, 0, ".", ".");
  return $hasil_rupiah;
}
$id_rekam_medis=$_GET['qaz'];
$data_rekam_medis=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM tbl_rekam_medis
  INNER JOIN tbl_pasien ON tbl_rekam_medis.id_pasien=tbl_pasien.id_pasien
  LEFT JOIN tbl_jk ON tbl_pasien.id_jk=tbl_jk.id_jk WHERE id_rekam_medis='$id_rekam_medis'"));
  ?>
  <!doctype html>
    <html lang="en">
    <head>
      <!-- Required meta tags -->
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

      <title><?= $data_rekam_medis['nama_pasien']; ?> <?= $data_rekam_medis['tgl_periksa']; ?></title>
      <style type="text/css">
        html,body{
          margin: auto;
          font-family: "Times New Roman", Times, serif;
          padding: 5px;
          font-size: 10pt;
        } 
        @page {
          size: A4;
          margin: 0px 0px 0px 0px;
          size: portrait;
        }
        .container{
          padding: 10px 3cm 1cm 3cm;
          background-color: white;
          margin: auto;
          width: 29.7cm;
        }
      </style>
    </head>
    <body>
      <div class="container">
        <table>
          <tr>
            <td>
              <img width="60" src="assets/img/<?= $row_pengaturan['logo']; ?>">
            </td>
            <td>
              <h2><?= $row_pengaturan['nama_aplikasi'] ?></h2>
            </td>
          </tr>
        </table>
        <hr>
        <table  cellpadding="3" cellspacing="1" width="100%">
          <tr>
            <td>Nama</td>
            <td>: <?= $data_rekam_medis['nama_pasien']; ?></td>
            <td>Tanggal/waktu</td>
            <td>: <?= $data_rekam_medis['tgl_periksa']; ?></td>
          </tr>
          <tr>
            <td>Umur</td>
            <td>: <?= $data_rekam_medis['usia']; ?> Tahun</td>
            <td>Keluhan</td>
            <td>: <?= $data_rekam_medis['keluhan']; ?></td>
          </tr>
          <tr>
            <td>Jenis Kelamin</td>
            <td>: <?= $data_rekam_medis['jenis_kelamin']; ?></td>
            <td>Alamat</td>
            <td>: <?= $data_rekam_medis['alamat']; ?></td>
          </tr>
          <tr>
            <td colspan="4">
              <b>PEMERIKSAAN FISIK</b>
              <?= $data_rekam_medis['pemeriksaan_fisik']; ?>
            </td>
          </tr>
          <tr>
            <td colspan="4">
              <b>DIAGNOSA</b>
              <?php 
              if ($data_rekam_medis['diagnosa']!=="") {
                ?>
                <br>
                <?= $data_rekam_medis['diagnosa']; ?>
              <?php }else{ ?>
                <br><br><br><br>
              <?php } ?>
            </td>
          </tr>
          <tr>
            <td colspan="4">
              <b>TERAPI</b>
              <?php 
              if ($data_rekam_medis['terapi']!=="") {
                ?>
                <br>
                <?= $data_rekam_medis['terapi']; ?>
              <?php }else{ ?>
                <br><br><br><br>
              <?php } ?>
            </td>
          </tr>
          <tr>
            <td colspan="2">
              <b>PEMERIKSAAN LAB DASAR</b><br>
              <?= rupiah($data_rekam_medis['biaya_periksa']); ?>
            </td>
            <td colspan="2">
              <b>BIAYA PEMERIKSAAN</b><br>
              <?= rupiah($data_rekam_medis['biaya']); ?>
            </td>
          </tr>
          <tr>
            <td colspan="4">
              <b>OBAT</b>
              <?php 
              $daftar_obat=mysqli_query($koneksi,"SELECT * FROM rekam_medis_obat INNER JOIN tbl_obat ON rekam_medis_obat.id_obat=tbl_obat.id_obat WHERE id_rekam_medis='$id_rekam_medis'");
              while ($t=mysqli_fetch_array($daftar_obat)) {
                ?>
                <tr style="border-collapse: collapse; border: 1px solid black;">
                  <td><?= $t['nama_obat']; ?></td>
                  <td><?= $t['jenis_obat']; ?> (Qty <?= $t['jml']; ?>)</td>
                  <td>
                    <?php 
                    $h_jum=$t['harga_jual']*$t['jml'];
                    echo rupiah($h_jum);
                    ?>
                  </td>
                </tr>
              <?php } ?>
            </td>
          </tr>
          <tr>
            <td colspan="4">
              <b>TOTAL BIAYA</b><br>
              <?php 
              $result = mysqli_query($koneksi, "SELECT SUM(tbl_obat.harga_jual*rekam_medis_obat.jml) AS total_sum FROM rekam_medis_obat INNER JOIN tbl_obat ON rekam_medis_obat.id_obat=tbl_obat.id_obat WHERE rekam_medis_obat.id_rekam_medis='$id_rekam_medis'"); 
              $row = mysqli_fetch_assoc($result); 
              $sum = $row['total_sum'];
              $biaya_p=$data_rekam_medis['biaya_periksa'];
              $biaya_q=$data_rekam_medis['biaya'];
              $hasil=$sum+$biaya_p+$biaya_q;
              echo rupiah($hasil);
              ?>
            </td>
          </tr>
        </table>
        <hr>
        <br>
        <table width="100%">
          <tr>
            <td>
              Mengetahui,<br>
              Perawat
              <br><br><br><br>
              (......................................)
            </td>
            <td style="text-align: center;">

            </td>
          </tr>
        </table>
      </div>
      <!-- Optional JavaScript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script type="text/javascript">window.print();</script>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    </body>
    </html>