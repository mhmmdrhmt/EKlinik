<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
date_default_timezone_set("Asia/Jakarta");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <base href="./">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/<?= $row_pengaturan['logo']; ?>">

  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->
  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
    <link href="vendors/@coreui/chartjs/css/coreui-chartjs.css" rel="stylesheet">
  </head>
  <body>
    <div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
      <?php 
      require_once"template/menu.php";
      ?>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb my-0 ms-2">
          <li class="breadcrumb-item">
            <!-- if breadcrumb is single--><span>Home</span>
          </li>
          <li class="breadcrumb-item active"><span>Dashboard</span></li>
          <li class="breadcrumb-item active"><span style="color: black;"><?= date('d-M-Y'); ?></span></li>
        </ol>
      </nav>
    </div>
  </header>
  <div class="body flex-grow-1 px-3">
    <div class="container-lg">
      <div class="row">

        <div class="col-6 col-lg-3">
          <div class="card">
            <div class="card-body p-3 d-flex align-items-center">
              <div class="bg-primary text-white p-3 me-3">
                <svg class="icon icon-xl">
                  <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-settings"></use>
                </svg>
              </div>
              <div>
                <div class="fs-6 fw-semibold text-primary">
                  <?php 
                  $data_pasien=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tbl_pasien"));
                  echo $data_pasien;
                  ?>
                </div>
                <div class="text-medium-emphasis text-uppercase fw-semibold small">PASIEN</div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.col-->
        <div class="col-6 col-lg-3">
          <div class="card">
            <div class="card-body p-3 d-flex align-items-center">
              <div class="bg-info text-white p-3 me-3">
                <svg class="icon icon-xl">
                  <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-laptop"></use>
                </svg>
              </div>
              <div>
                <div class="fs-6 fw-semibold text-info">
                  <?php 
                  $dataobat=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tbl_obat"));
                  echo $dataobat;
                  ?>
                </div>
                <div class="text-medium-emphasis text-uppercase fw-semibold small">DATA OBAT</div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.col-->
        <div class="col-6 col-lg-3">
          <div class="card">
            <div class="card-body p-3 d-flex align-items-center">
              <div class="bg-warning text-white p-3 me-3">
                <svg class="icon icon-xl">
                  <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-moon"></use>
                </svg>
              </div>
              <div>
                <div class="fs-6 fw-semibold text-warning">
                  <?php 
                  $data_rekam_medis=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM tbl_rekam_medis"));
                  echo $data_rekam_medis;
                  ?>
                </div>
                <div class="text-medium-emphasis text-uppercase fw-semibold small">DATA REKAM MEDIS</div>
              </div>
            </div>
          </div>
        </div>
        <!-- /.col-->


        <div class="col-6 col-lg-3">
          <div class="card">
            <div class="card-body p-3 d-flex align-items-center">
              <div class="bg-danger text-white p-3 me-3">
                <svg class="icon icon-xl">
                  <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-bell"></use>
                </svg>
              </div>
              <div>
                <div class="fs-6 fw-semibold text-danger">
                  <?php 
                  $user=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM user"));
                  echo $user;
                  ?>
                </div>
                <div class="text-medium-emphasis text-uppercase fw-semibold small">USER</div>
              </div>
            </div>
          </div>
        </div>

      </div>
      <br>

      <div class="card mb-4">
        <div class="card">
          <div class="card-body">
            <img src="assets/img/<?= $row_pengaturan['slide']; ?>" style="width: 100%;">
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php 
require_once"template/footer.php";
?>
</div>
<!-- CoreUI and necessary plugins-->
<script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
<script src="vendors/simplebar/js/simplebar.min.js"></script>
<!-- Plugins and scripts required by this view-->
<script src="vendors/chart.js/js/chart.min.js"></script>
<script src="vendors/@coreui/chartjs/js/coreui-chartjs.js"></script>
<script src="vendors/@coreui/utils/js/coreui-utils.js"></script>
<script src="js/main.js"></script>
<script>
</script>

</body>
</html>