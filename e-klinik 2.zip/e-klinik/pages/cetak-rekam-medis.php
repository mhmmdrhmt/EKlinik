<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
	header("location: login.php");
}
include"../config/koneksi.php";
function formatTanggal($date){
 // ubah string menjadi format tanggal
	return date('d-M-Y', strtotime($date));
}
function rupiah($angka){
  $hasil_rupiah = "Rp. " . number_format($angka, 0, ".", ".");
  return $hasil_rupiah;
}
$dari_tgl=$_POST['dari_tgl'];
$sampai_tgl=$_POST['sampai_tgl'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laporan Data Rekam Medis <?= formatTanggal($dari_tgl); ?> sampai <?= formatTanggal($sampai_tgl); ?></title>
	<link rel="icon" type="image/png" sizes="192x192" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/img/clinic.png">
	<style type="text/css">
		@media print{@page {size: landscape}}
		.page {
			min-height: 210mm;
			width: 297mm;
			margin: auto;
			font-family: "Times New Roman", Times, serif;
			font-size: 10pt;
		}
	</style>
</head>
<body>
	<div class="page">
		<center>
			<h3>Laporan Data Rekam Medis <?= formatTanggal($dari_tgl); ?> sampai <?= formatTanggal($sampai_tgl); ?></h3>
		</center>
		<table width="100%" border="1" style="border-collapse: collapse;">
			<tr>
				<th>NO</th>

				<th scope="col">PETUGAS KLINIK</th>
				<th scope="col">TGL PERIKSA</th>
				<th scope="col">NAMA PASIEN</th>
				<th scope="col">KELUHAN</th>
				<th scope="col">HASIL PERIKSA</th>
				<th scope="col">KETERANGAN</th>
				<th scope="col">DIBERIKAN RESEP</th>
				<th scope="col">BIAYA PERIKSA</th>
			</tr>
			<?php
			$no=1;
			$rekam_medis=mysqli_query($koneksi,"SELECT * FROM tbl_rekam_medis
				INNER JOIN user ON tbl_rekam_medis.id_user=user.id_user
				INNER JOIN tbl_pasien ON tbl_rekam_medis.id_pasien=tbl_pasien.id_pasien WHERE tgl_periksa BETWEEN '$dari_tgl' AND '$sampai_tgl' ORDER BY tgl_periksa DESC");
			while ($row_rekam_medis=mysqli_fetch_array($rekam_medis)) {
				?>
				<tr>
					<td align="center"><?= $no++; ?>.</td>
					<td><span class="badge bg-primary" style="font-size: 10pt;"><?= $row_rekam_medis['nama']; ?></span></td>
					<td><span style="font-size: 10pt;" class="badge bg-info"><?= $row_rekam_medis['tgl_periksa']; ?></span></td>
					<td><span class="badge bg-success" style="font-size: 10pt;"><?= $row_rekam_medis['nama_pasien']; ?></span></td>
					<td><?= $row_rekam_medis['keluhan']; ?></td>
					<td><?= $row_rekam_medis['hasil_periksa']; ?></td>
					<td><?= $row_rekam_medis['keterangan']; ?></td>
					<td><?= $row_rekam_medis['memberi_resep']; ?></td>
					<td><span style="font-size: 10pt;" class="badge bg-info"><?= rupiah($row_rekam_medis['biaya_periksa']); ?></span></td>
				</tr>
			<?php } ?>
		</table>
	</div>
	<script type="text/javascript">
		window.print();
	</script>
</body>
</html>