<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
function formatTanggal($date){
 // ubah string menjadi format tanggal
 return date('d-M-Y', strtotime($date));
}
function rupiah($angka){
  $hasil_rupiah = "Rp. " . number_format($angka, 0, ".", ".");
  return $hasil_rupiah;
}
// Simpan data
if (isset($_POST['simpan'])) {
  $nama_obat=mysqli_real_escape_string($koneksi, $_POST['nama_obat']);
  $jenis_obat=mysqli_real_escape_string($koneksi, $_POST['jenis_obat']);
  $dosis=mysqli_real_escape_string($koneksi, $_POST['dosis']);
  $stok_obat=mysqli_real_escape_string($koneksi, $_POST['stok_obat']);
  $stok_keluar=0;
  $tgl_kadaluarsa=mysqli_real_escape_string($koneksi, $_POST['tgl_kadaluarsa']);
  $harga=mysqli_real_escape_string($koneksi, $_POST['harga']);
  $harga_jual=mysqli_real_escape_string($koneksi, $_POST['harga_jual']);
  $profit=0;
  $input=mysqli_query($koneksi,"INSERT INTO tbl_obat VALUES(NULL,'$nama_obat','$jenis_obat','$dosis','$stok_obat','$stok_keluar','$tgl_kadaluarsa','$harga','$harga_jual','$profit')");
  if ($input>0) {
    echo "<script>window.alert('Data Obat behasil ditambahkan')
    window.location='data-obat.php'</script>";
  }else{
    echo "<script>window.alert('data Obat gagal ditambahkan !!!')
    window.location='data-obat.php'</script>";
  }
}
// Edit data pasien
if (isset($_POST['edit'])) {
  $id_obat=mysqli_real_escape_string($koneksi, $_POST['id_obat']);
  $nama_obat=mysqli_real_escape_string($koneksi, $_POST['nama_obat']);
  $jenis_obat=mysqli_real_escape_string($koneksi, $_POST['jenis_obat']);
  $dosis=mysqli_real_escape_string($koneksi, $_POST['dosis']);
  $stok_obat=mysqli_real_escape_string($koneksi, $_POST['stok_obat']);
  $tgl_kadaluarsa=mysqli_real_escape_string($koneksi, $_POST['tgl_kadaluarsa']);
  $harga=mysqli_real_escape_string($koneksi, $_POST['harga']);
  $harga_jual=mysqli_real_escape_string($koneksi, $_POST['harga_jual']);
  $edit=mysqli_query($koneksi,"UPDATE tbl_obat SET nama_obat='$nama_obat', jenis_obat='$jenis_obat', dosis='$dosis', stok_obat='$stok_obat', tgl_kadaluarsa='$tgl_kadaluarsa', harga='$harga', harga_jual='$harga_jual' WHERE id_obat='$id_obat'");
  if ($edit>0) {
    echo "<script>window.alert('data obat behasil diupdate')
    window.location='data-obat.php'</script>";
  }else{
    echo "<script>window.alert('data obat gagal diupdate !!!')
    window.location='data-obat.php'</script>";
  }
}
// hapus data
if (isset($_GET['aksi'])=='del') {
  $id_obat=mysqli_real_escape_string($koneksi, $_GET['aqsw']);
  $hapus=mysqli_query($koneksi,"DELETE FROM tbl_obat WHERE id_obat='$id_obat'");
  if ($hapus>0) {
    echo "<script>window.alert('data obat behasil dihapus')
    window.location='data-obat.php'</script>";
  }else{
    echo "<script>window.alert('data obat gagal dihapus !!!')
    window.location='data-obat.php'</script>";
  }
}
if (isset($_POST['import'])) {
  require('assets/excel_reader2.php');
// upload file xls
  $target = basename($_FILES['file_obat']['name']) ;
  move_uploaded_file($_FILES['file_obat']['tmp_name'], $target);
// beri permisi agar file xls dapat di baca
  chmod($_FILES['file_obat']['name'],0777);
// mengambil isi file xls
  $data = new Spreadsheet_Excel_Reader($_FILES['file_obat']['name'],false);
// menghitung jumlah baris data yang ada
  $jumlah_baris = $data->rowcount($sheet_index=0);
// jumlah default data yang berhasil di import
  $berhasil = 0;
  for ($i=2; $i<=$jumlah_baris; $i++){
    $nama_obat = $data->val($i, 1);
    $jenis_obat = $data->val($i, 2);
    $dosis = $data->val($i, 3);
    $stok_obat = $data->val($i, 4);
    $tgl_kadaluarsa = $data->val($i, 5);
    $harga = $data->val($i, 6);
    $harga_jual = $data->val($i, 7);
    $stok_keluar=0;
    $profit=0;
    if ($nama_obat != "" && $jenis_obat !="" && $dosis !="" && $stok_obat !="" && $tgl_kadaluarsa !="" && $harga !="" ) {
      mysqli_query($koneksi,"INSERT INTO tbl_obat VALUES(NULL,'$nama_obat','$jenis_obat','$dosis','$stok_obat','$stok_keluar','$tgl_kadaluarsa','$harga','$harga_jual','$profit')");
      $berhasil++;
    }
  }
  unlink($_FILES['file_obat']['name']);
  echo "<script>window.alert('berhasil import $berhasil data obat')
  window.location='data-obat.php'</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- <base href="./../"> -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/<?= $row_pengaturan['logo']; ?>">
  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap4.min.css">

  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
    <link rel="canonical" href="https://coreui.io/docs/content/tables/">
  </head>
  <body>
    <div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
      <?php 
      require_once"template/menu.php";
      ?>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb my-0 ms-2">
          <li class="breadcrumb-item">
            <a style="text-decoration: none;" href="index.php">Home</a>
          </li>
          <li class="breadcrumb-item active">
            <span>Data Obat</span>
          </li>
          <li class="breadcrumb-item active"><span style="color: black;"><?= date('d-M-Y'); ?></span></li>
        </ol>
      </nav>
    </div>
  </header>
  <div class="body flex-grow-1 px-3" style="background-color: #06d6a0;"><br>
    <div class="container-lg">
      <div class="card mb-4">
        <div class="card-header">
          <strong>Data Obat</strong>
        </div>
        <div class="card-body">
          <a href="#" style="font-size: 10pt;" class="btn btn-primary" data-toggle="modal" data-target="#tambahData">
            <img src="https://cdn-icons-png.flaticon.com/512/2968/2968933.png" style="width: 20px;"> Tambah Data</a>
            <a href="" style="font-size: 10pt;" class="btn btn-primary" data-toggle="modal" data-target="#import"> Import Data</a>
            <a href="cetak-dataobat.php" class="btn btn-primary" target="_blank" style="font-size: 10pt;">
              <img src="https://cdn-icons-png.flaticon.com/512/3233/3233446.png" style="width: 20px;"> Cetak Data</a>
              <div class="example">
                <div class="tab-content rounded-bottom">
                  <div class="tab-pane p-3 active preview" role="tabpanel" id="preview-877">
                    <table style="font-size: 10pt;" id="example" class="table table-responsive">
                      <thead>
                        <tr>
                          <th scope="col">OPSI</th>
                          <!-- <th scope="col">ID OBAT</th> -->
                          <th scope="col">NAMA OBAT</th>
                          <th scope="col">JENIS OBAT</th>
                          <th scope="col">DOSIS</th>
                          <th scope="col">STOCK OBAT</th>
                          <th scope="col">STOCK KELUAR</th>
                          <th scope="col">TANGGAL KADALUARSA</th>
                          <th>HARGA BELI</th>
                          <th>HARGA JUAL</th>
                          <th>PROFIT</th>
                        </tr>
                      </thead>  
                      <?php 
                      $obat=mysqli_query($koneksi,"SELECT * FROM tbl_obat ORDER BY nama_obat ASC");
                      while ($row_obat=mysqli_fetch_array($obat)) {
                        ?>
                        <tr>
                          <td>
                            <table border="0">
                              <tr>
                                <td>
                                  <a href="data-obat.php?aksi=del&aqsw=<?= $row_obat['id_obat']; ?>" onclick="return confirm('Ingin hapus data ini ?')"><img src="https://cdn-icons-png.flaticon.com/512/5028/5028066.png" style="width: 30px;"></a>
                                </td>
                                <td>
                                  <a data-toggle="modal" data-target="#edit<?= $row_obat['id_obat']; ?>"><img src="https://cdn-icons-png.flaticon.com/512/5996/5996831.png" style="width: 30px;"></a>
                                </td>
                              </tr>
                            </table>
                          </td>
                          
                          <td><?= $row_obat['nama_obat']; ?></td>
                          <td><span style="font-size: 10pt;" class="badge bg-info"><?= $row_obat['jenis_obat']; ?></span></td>
                          <td><?= $row_obat['dosis']; ?></td>
                          <td><?= $row_obat['stok_obat']; ?></td>
                          <td><?= $row_obat['stok_keluar']; ?></td>
                          <td><?= formatTanggal($row_obat['tgl_kadaluarsa']); ?></td>
                          <td><span class="badge bg-warning" style="font-size: 11pt;"><?= rupiah($row_obat['harga']); ?></span></td>
                          <td><span class="badge bg-success" style="font-size: 11pt;"><?= rupiah($row_obat['harga_jual']); ?></span></td>
                          <td><span class="badge bg-light text-dark" style="font-size: 11pt;"><?= rupiah($row_obat['profit']); ?></span></td>
                        </tr> 
                        <div class="modal fade" id="edit<?= $row_obat['id_obat']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                          <div class="modal-dialog" role="document">
                            <div class="modal-content">
                              <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLongTitle">Edit Data Obat</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <form action="" method="post">
                                <div class="modal-body">
                                  <div class="form-group">
                                    <label>Nama Obat</label>
                                    <input type="hidden" name="id_obat" value="<?= $row_obat['id_obat']; ?>">
                                    <input type="text" value="<?= $row_obat['nama_obat']; ?>" name="nama_obat" placeholder="Nama Obat" class="form-control form-control-sm is-valid" required>
                                  </div>
                                  <div class="form-group">
                                    <label>Jenis Obat</label>
                                    <input type="text" name="jenis_obat" value="<?= $row_obat['jenis_obat']; ?>" placeholder="Jenis Obat" class="form-control form-control-sm is-valid" required>
                                  </div>
                                  <div class="form-group">
                                    <label>Dosis Obat</label>
                                    <input type="text" name="dosis" value="<?= $row_obat['dosis']; ?>" placeholder="Dosis Obat" class="form-control form-control-sm is-valid" required>
                                  </div>
                                  <div class="form-group">
                                    <label>Stok Obat</label>
                                    <input type="text" name="stok_obat" value="<?= $row_obat['stok_obat']; ?>" placeholder="Stok Obat" class="form-control form-control-sm is-valid" required>
                                  </div>
                                  <div class="form-group">
                                    <label>Tanggal Kadaluarsa Obat</label>
                                    <input type="date" name="tgl_kadaluarsa" value="<?= $row_obat['tgl_kadaluarsa']; ?>" placeholder="Tgl Kadaluarsa Obat" class="form-control form-control-sm is-valid" required>
                                  </div>
                                  <div class="form-group">
                                    <label>Harga Obat</label>
                                    <input type="number" name="harga" value="<?= $row_obat['harga']; ?>" placeholder="Harga Obat" class="form-control form-control-sm is-valid" required>
                                  </div>  
                                  <div class="form-group">
                                    <label>Harga Jual Obat</label>
                                    <input type="number" name="harga_jual" value="<?= $row_obat['harga_jual']; ?>" placeholder="Harga Jual Obat" class="form-control form-control-sm is-valid" required>
                                  </div>  
                                </div>
                                <div class="modal-footer">
                                  <button type="submit" name="edit" class="btn btn-primary">Update</button>
                                </div>
                              </form>
                            </div>
                          </div>
                        </div>
                      <?php } ?>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Tambah Data Obat</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="" method="post">
          <div class="modal-body">
            <div class="form-group">
              <label>Nama Obat</label>
              <input type="text" name="nama_obat" placeholder="Nama Obat" class="form-control form-control-sm is-valid" required>
            </div>
            <div class="form-group">
              <label>Jenis Obat</label>
              <input type="text" name="jenis_obat" placeholder="Jenis Obat" class="form-control form-control-sm is-valid" required>
            </div>
            <div class="form-group">
              <label>Dosis Obat</label>
              <input type="text" name="dosis" placeholder="Dosis Obat" class="form-control form-control-sm is-valid" required>
            </div>
            <div class="form-group">
              <label>Stok Obat</label>
              <input type="number" name="stok_obat" placeholder="Stok Obat" class="form-control form-control-sm is-valid" required>
            </div>
            <div class="form-group">
              <label>Tanggal Kadaluarsa Obat</label>
              <input type="date" name="tgl_kadaluarsa" placeholder="Tgl Kadaluarsa Obat" class="form-control form-control-sm is-valid" required>
            </div>
            <div class="form-group">
              <label>Harga Obat</label>
              <input type="number" autocomplete="off" name="harga" placeholder="Harga Obat" class="form-control form-control-sm is-valid" required>
            </div>  
            <div class="form-group">
              <label>Harga Jual Obat</label>
              <input type="number" autocomplete="off" name="harga_jual" placeholder="Harga Jual Obat" class="form-control form-control-sm is-valid" required>
            </div>  
          </div>
          <div class="modal-footer">
            <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade" id="cetakData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Cetak Data Obat</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="" method="post">
          <div class="modal-body">
            <div class="form-group">
              <label>Dari Tanggal</label>
              <input type="date" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Dari Tanggal" name="dari_tgl" required>
            </div>
            <div class="form-group">
              <label>Sampai Tanggal</label>
              <input type="date" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Sampai Tanggal" name="sampai_tgl" required>
            </div>
          </div>
          <div class="modal-footer">
            <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
            <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <div class="modal fade" id="import" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle">Import Data Obat</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="" method="post" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="form-group">
              <label>File</label>
              <input type="file" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Dari Tanggal" name="file_obat" required>
              <a href="../format-file-obat.xls" target="_blank"><u>Download Format file Data Obat</u></a>
            </div>
          </div>
          <div class="modal-footer">
            <button type="submit" name="import" class="btn btn-primary">Submit</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
  <script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
  <script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  <script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
  <script src="vendors/simplebar/js/simplebar.min.js"></script>
  <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
  <script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function() {
      $('#example').DataTable();
    } );
  </script>
</body>
</html>