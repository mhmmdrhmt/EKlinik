<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
date_default_timezone_set("Asia/Jakarta");
function formatTanggal($date){
 // ubah string menjadi format tanggal
 return date('d-M-Y', strtotime($date));
}
// Simpan data
if (isset($_POST['simpan'])) {
  $tgl_terdaftar=mysqli_real_escape_string($koneksi, $_POST['tgl_terdaftar']);
  $nama_pasien=mysqli_real_escape_string($koneksi, $_POST['nama_pasien']);
  $alamat=mysqli_real_escape_string($koneksi, $_POST['alamat']);
  $usia=mysqli_real_escape_string($koneksi, $_POST['usia']);
  $id_jk=mysqli_real_escape_string($koneksi, $_POST['id_jk']);
  $nama_ibu=mysqli_real_escape_string($koneksi, $_POST['nama_ibu']);
  $id_agama=mysqli_real_escape_string($koneksi, $_POST['id_agama']);
  $no_telp=mysqli_real_escape_string($koneksi, $_POST['no_telp']);
  $gol_darah=mysqli_real_escape_string($koneksi, $_POST['gol_darah']);
  $pekerjaan=mysqli_real_escape_string($koneksi, $_POST['pekerjaan']);
  $input=mysqli_query($koneksi,"INSERT INTO tbl_pasien VALUES(NULL,'$tgl_terdaftar','$nama_pasien','$alamat','$usia','$id_jk','$nama_ibu','$id_agama','$no_telp','$gol_darah','$pekerjaan')");
  if ($input>0) {
    echo "<script>window.alert('data pasien behasil ditambahkan')
    window.location='data-pasien.php'</script>";
  }else{
    echo "<script>window.alert('data pasien gagal ditambahkan !!!')
    window.location='data-pasien.php'</script>";
  }
}
// Edit data pasien
if (isset($_POST['edit'])) {
  $id_pasien=mysqli_real_escape_string($koneksi, $_POST['id_pasien']);
  $tgl_terdaftar=mysqli_real_escape_string($koneksi, $_POST['tgl_terdaftar']);
  $nama_pasien=mysqli_real_escape_string($koneksi, $_POST['nama_pasien']);
  $alamat=mysqli_real_escape_string($koneksi, $_POST['alamat']);
  $usia=mysqli_real_escape_string($koneksi, $_POST['usia']);
  $id_jk=mysqli_real_escape_string($koneksi, $_POST['id_jk']);
  $nama_ibu=mysqli_real_escape_string($koneksi, $_POST['nama_ibu']);
  $id_agama=mysqli_real_escape_string($koneksi, $_POST['id_agama']);
  $no_telp=mysqli_real_escape_string($koneksi, $_POST['no_telp']);
  $gol_darah=mysqli_real_escape_string($koneksi, $_POST['gol_darah']);
  $pekerjaan=mysqli_real_escape_string($koneksi, $_POST['pekerjaan']);
  $edit=mysqli_query($koneksi,"UPDATE tbl_pasien SET tgl_terdaftar='$tgl_terdaftar', nama_pasien='$nama_pasien', alamat='$alamat', usia='$usia', id_jk='$id_jk', nama_ibu='$nama_ibu', id_agama='$id_agama', no_telp='$no_telp', gol_darah='$gol_darah', pekerjaan='$pekerjaan' WHERE id_pasien='$id_pasien'");
  if ($edit>0) {
    echo "<script>window.alert('data pasien behasil diupdate')
    window.location='data-pasien.php'</script>";
  }else{
    echo "<script>window.alert('data pasien gagal diupdate !!!')
    window.location='data-pasien.php'</script>";
  }
}
// hapus data
if (isset($_GET['aksi'])=='del') {
  $id_pasien=mysqli_real_escape_string($koneksi, $_GET['aqsw']);
  $hapus=mysqli_query($koneksi,"DELETE FROM tbl_pasien WHERE id_pasien='$id_pasien'");
  if ($hapus>0) {
    echo "<script>window.alert('data pasien behasil dihapus')
    window.location='data-pasien.php'</script>";
  }else{
    echo "<script>window.alert('data pasien gagal dihapus !!!')
    window.location='data-pasien.php'</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- <base href="./../"> -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/<?= $row_pengaturan['logo']; ?>">
  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap4.min.css">

  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
    <link rel="canonical" href="https://coreui.io/docs/content/tables/">
  </head>
  <body>
    <div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
      <?php 
      require_once"template/menu.php";
      ?>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb my-0 ms-2">
          <li class="breadcrumb-item">
            <a style="text-decoration: none;" href="index.php">Home</a>
          </li>
          <li class="breadcrumb-item active">
            <span>Data Pasien</span>
          </li>
          <li class="breadcrumb-item active"><span style="color: black;"><?= date('d-M-Y'); ?></span></li>
        </ol>
      </nav>
    </div>
  </header>
  <div class="body flex-grow-1 px-3" style="background-color: #06d6a0;"><br>
    <div class="container-lg">
      <div class="card mb-4">
        <div class="card-header">
          <strong>Data Pasien</strong>
        </div>
        <div class="card-body">
          <a href="#" style="font-size: 10pt;" class="btn btn-primary" data-toggle="modal" data-target="#tambahData">
            <img src="https://cdn-icons-png.flaticon.com/512/863/863782.png" style="width: 20px;"> Tambah Data</a>
            <a href="" style="font-size: 10pt;" class="btn btn-primary" data-toggle="modal" data-target="#cetakData">
              <img src="https://cdn-icons-png.flaticon.com/512/3233/3233446.png" style="width: 20px;"> Cetak Data</a>
              <div class="example">
                <div class="tab-content rounded-bottom">
                  <div class="table-responsive" role="tabpanel" id="preview-877">
                    <table style="font-size: 9pt;" id="example" class="table table-responsive">
                      <thead>
                        <tr>
                          <th scope="col">OPSI</th>
                          <th scope="col">ID PASIEN</th>
                          <th scope="col">TGL TERDAFTAR</th>
                          <th scope="col">NAMA PASIEN</th>
                          <th scope="col">ALAMAT</th>
                          <th scope="col">USIA</th>
                          <th scope="col">JK</th>
                          <th scope="col">NAMA IBU KANDUNG</th>
                          <th scope="col">AGAMA</th>
                          <th scope="col">NO TELP</th>
                          <th scope="col">GOL DARAH</th>
                          <th scope="col">PEKERJAAN</th>
                        </tr>
                      </thead>
                      <?php 
                      $pasien=mysqli_query($koneksi,"SELECT * FROM tbl_pasien
                        INNER JOIN tbl_jk ON tbl_pasien.id_jk=tbl_jk.id_jk
                        INNER JOIN tbl_agama ON tbl_pasien.id_agama=tbl_agama.id_agama ORDER BY tbl_pasien.tgl_terdaftar DESC");
                      while ($row_pasien=mysqli_fetch_array($pasien)) {
                       ?>
                       <tr>
                        <td>
                          <table border="0">
                            <tr>
                              <td>
                                <a href="data-pasien.php?aksi=del&aqsw=<?= $row_pasien['id_pasien']; ?>" onclick="return confirm('Ingin hapus data ini ?')"><img src="https://cdn-icons-png.flaticon.com/512/5028/5028066.png" style="width: 30px;"></a>
                              </td>
                              <td>
                                <a data-toggle="modal" data-target="#edit<?= $row_pasien['id_pasien']; ?>"><img src="https://cdn-icons-png.flaticon.com/512/5996/5996831.png" style="width: 30px;"></a>
                              </td>
                            </tr>
                          </table>     
                        </td>
                        <td><?= $row_pasien['id_pasien']; ?></td>
                        <td><?= formatTanggal($row_pasien['tgl_terdaftar']); ?></td>
                        <td><span style="font-size: 10pt;" class="badge bg-success"><?= $row_pasien['nama_pasien']; ?></span></td>
                        <td><?= $row_pasien['alamat']; ?></td>
                        <td><?= $row_pasien['usia']; ?></td>
                        <td><?= $row_pasien['jenis_kelamin']; ?></td>
                        <td><?= $row_pasien['nama_ibu']; ?></td>
                        <td><?= $row_pasien['agama']; ?></td>
                        <td><?= $row_pasien['no_telp']; ?></td>
                        <td><?= $row_pasien['gol_darah']; ?></td>
                        <td><?= $row_pasien['pekerjaan']; ?></td>
                      </tr>
                      <div class="modal fade" id="edit<?= $row_pasien['id_pasien']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h5 class="modal-title" id="exampleModalLongTitle">Edit Data Pasien</h5>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <form action="" method="post">
                              <div class="modal-body">
                                <div class="form-group">
                                  <label>Tanggal Pendaftaran</label>
                                  <input type="hidden" name="id_pasien" value="<?= $row_pasien['id_pasien']; ?>">
                                  <input type="date" value="<?= $row_pasien['tgl_terdaftar']; ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Nama Pasien" name="tgl_terdaftar" required>
                                </div>
                                <div class="form-group">
                                  <label>Nama Pasien</label>
                                  <input type="text" value="<?= $row_pasien['nama_pasien']; ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Nama Pasien" name="nama_pasien" required>
                                </div>
                                <div class="form-group">
                                  <label>Alamat</label>
                                  <textarea class="form-control form-control-sm is-valid" name="alamat"><?= $row_pasien['alamat']; ?></textarea>
                                </div>
                                <div class="form-group">
                                  <label>Usia Pasien</label>
                                  <input type="number" maxlength="2" value="<?= $row_pasien['usia']; ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Usia Pasien" name="usia" required>
                                </div>
                                <div class="form-group">
                                  <label>Jenis Kelamin Pasien</label>
                                  <select class="form-control form-control-sm is-valid" name="id_jk" required>
                                    <?php 
                                    $jk=mysqli_query($koneksi,"SELECT * FROM tbl_jk");
                                    while ($row_jk=mysqli_fetch_array($jk)) {
                                      ?>
                                      <option value="<?= $row_jk['id_jk']; ?>" <?= ($row_jk['jenis_kelamin'] == $row_pasien['jenis_kelamin'])? "selected" : "" ?>> <?= $row_jk['jenis_kelamin']; ?></option>
                                    <?php } ?>
                                  </select>
                                </div>
                                <div class="form-group">
                                  <label>Nama Ibu Kandung</label>
                                  <input type="text" value="<?= $row_pasien['nama_ibu']; ?>" class="form-control form-control-sm" autocomplete="off" placeholder="Nama Ibu Kandung" name="nama_ibu">
                                </div>
                                <div class="form-group">
                                  <label>Agama</label>
                                  <select class="form-control form-control-sm is-valid" name="id_agama" required>
                                    <?php 
                                    $agama=mysqli_query($koneksi,"SELECT * FROM tbl_agama");
                                    while ($row_agama=mysqli_fetch_array($agama)) {
                                      ?>
                                      <option value="<?= $row_agama['id_agama']; ?>" <?= ($row_agama['agama'] == $row_pasien['agama'])? "selected" : "" ?>> <?= $row_agama['agama']; ?></option>
                                    <?php } ?>
                                  </select>
                                </div>
                                <div class="form-group">
                                  <label>No Telp</label>
                                  <input type="number" maxlength="12" value="<?= $row_pasien['no_telp']; ?>" class="form-control form-control-sm" autocomplete="off" placeholder="No telp" name="no_telp">
                                </div>
                                <div class="form-group">
                                  <label>Gol darah</label>
                                  <input type="text" class="form-control form-control-sm" value="<?= $row_pasien['gol_darah']; ?>" name="gol_darah" placeholder="Golongan Darah">
                                </div>
                                <div class="form-group">
                                  <label>Pekerjaan</label>
                                  <input type="text" value="<?= $row_pasien['pekerjaan']; ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Pekerjaan" name="pekerjaan">
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="submit" name="edit" class="btn btn-primary">Update</button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    <?php } ?>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah Data Pasien</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Tanggal Pendaftaran</label>
            <input type="date" value="<?= date('Y-m-d'); ?>" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Nama Pasien" name="tgl_terdaftar" required>
          </div>
          <div class="form-group">
            <label>Nama Pasien</label>
            <input type="text" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Nama Pasien" name="nama_pasien" required>
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <textarea class="form-control form-control-sm is-valid" name="alamat"></textarea>
          </div>
          <div class="form-group">
            <label>Usia Pasien</label>
            <input type="number" maxlength="2" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Usia Pasien" name="usia" required>
          </div>
          <div class="form-group">
            <label>Jenis Kelamin Pasien</label>
            <select class="form-control form-control-sm is-valid" name="id_jk" required>
              <option value="">--Pilih--</option>
              <?php 
              $jk=mysqli_query($koneksi,"SELECT * FROM tbl_jk");
              while ($row_jk=mysqli_fetch_array($jk)) {
                ?>
                <option value="<?= $row_jk['id_jk']; ?>"><?= $row_jk['jenis_kelamin']; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label>Nama Ibu Kandung</label>
            <input type="text" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Nama ibu Kandung" name="nama_ibu" required>
          </div>
          <div class="form-group">
            <label>Agama</label>
            <select class="form-control form-control-sm is-valid" name="id_agama" required>
              <option value="">--Pilih--</option>
              <?php 
              $agama=mysqli_query($koneksi,"SELECT * FROM tbl_agama");
              while ($row_agama=mysqli_fetch_array($agama)) {
                ?>
                <option value="<?= $row_agama['id_agama']; ?>"><?= $row_agama['agama']; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group">
            <label>No Telp</label>
            <input type="number" maxlength="12" class="form-control form-control-sm" autocomplete="off" placeholder="No telp" name="no_telp">
          </div>
          <div class="form-group">
            <label>Gol darah</label>
            <input type="text" name="gol_darah" autocomplete="off" class="form-control form-control-sm" placeholder="Golongan Darah">
          </div>
          <div class="form-group">
            <label>Pekerjaan</label>
            <input type="text" class="form-control form-control-sm is-valid" autocomplete="off" placeholder="Pekerjaan" name="pekerjaan">
          </div>
        </div>
        <div class="modal-footer">
          <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<div class="modal fade" id="cetakData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Cetak Data Pasien</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="cetak-data-pasien.php" target="_blank" method="post">
        <div class="modal-body">
          <div class="form-group">
            <label>Dari Tanggal</label>
            <input type="date" class="form-control form-control-sm is-valid" value="<?= date('Y-m-d'); ?>" autocomplete="off" placeholder="Dari Tanggal" name="dari_tgl" required>
          </div>
          <div class="form-group">
            <label>Sampai Tanggal</label>
            <input type="date" class="form-control form-control-sm is-valid" value="<?= date('Y-m-d'); ?>" autocomplete="off" placeholder="Sampai Tanggal" name="sampai_tgl" required>
          </div>
        </div>
        <div class="modal-footer">
          <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button> -->
          <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
<script src="vendors/simplebar/js/simplebar.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable();
  } );
</script>
</body>
</html>