<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
  header("location: login.php");
}
include"../config/koneksi.php";
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
function formatTanggal($date){
 // ubah string menjadi format tanggal
 return date('d-M-Y', strtotime($date));
}
// Simpan data
if (isset($_POST['simpan'])) {
  $nama=mysqli_real_escape_string($koneksi, $_POST['nama']);
  $username=mysqli_real_escape_string($koneksi, $_POST['username']);
  $password=mysqli_real_escape_string($koneksi, md5($_POST['password']));
  $id_jk=mysqli_real_escape_string($koneksi, $_POST['id_jk']);
  $email=mysqli_real_escape_string($koneksi, $_POST['email']);
  $no_telp=mysqli_real_escape_string($koneksi, $_POST['no_telp']);
  $ekstensi_diperbolehkan = array('png','jpg','JPG','PNG','jpeg','JPEG');
  $photo = $_FILES['photo']['name'];
  if ($photo!="") {
    $x = explode('.', $photo);
    $ekstensi = strtolower(end($x));
    $ukuran = $_FILES['photo']['size'];
    $file_tmp = $_FILES['photo']['tmp_name'];     
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
      if($ukuran <= 5000000){         
        move_uploaded_file($file_tmp, 'assets/img/'.$photo);
      }else{
        echo "<script>window.alert('Ukuran File Foto melebihi batas !!!')
        window.location='user'</script>";
      }
    }else{
      echo "<script>window.alert('ekstensi file tidak di perbolehkan !!!')
      window.location='user'</script>";
    }
  }else{
    $photo="";
  }
  $input=mysqli_query($koneksi,"INSERT INTO user VALUES(NULL,'$nama','$username','$password','$id_jk','$email','$no_telp','$photo')");
  if ($input) {
    echo "<script>window.alert('Data user behasil ditambahkan')
    window.location='user.php'</script>";
  }else{
    echo "<script>window.alert('data user gagal ditambahkan !!!')
    window.location='user.php'</script>";
  }
}
// hapus data
if (isset($_GET['aksi'])=='del') {
  $id_user=mysqli_real_escape_string($koneksi, $_GET['aqsw']);
  $hapus=mysqli_query($koneksi,"DELETE FROM user WHERE id_user='$id_user'");
  if ($hapus) {
    echo "<script>window.alert('data user behasil dihapus')
    window.location='user.php'</script>";
  }else{
    echo "<script>window.alert('data user gagal dihapus !!!')
    window.location='user.php'</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <!-- <base href="./../"> -->
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="CoreUI - Open Source Bootstrap Admin Template">
  <meta name="author" content="Łukasz Holeczek">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/<?= $row_pengaturan['logo']; ?>">
  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/favicon/ms-icon-144x144.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->
  <link rel="stylesheet" type="text/css" href="css/bootstrap.css"/>
  <link rel="stylesheet" type="text/css" href="css/dataTables.bootstrap4.min.css">

  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
    <link rel="canonical" href="https://coreui.io/docs/content/tables/">
  </head>
  <body>
    <div class="sidebar sidebar-dark sidebar-fixed" id="sidebar">
      <?php 
      require_once"template/menu.php";
      ?>
    </div>
    <div class="header-divider"></div>
    <div class="container-fluid">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb my-0 ms-2">
          <li class="breadcrumb-item">
            <a style="text-decoration: none;" href="index.php">Home</a>
          </li>
          <li class="breadcrumb-item active">
            <span>Data User</span>
          </li>
          <li class="breadcrumb-item active"><span style="color: black;"><?= date('d-M-Y'); ?></span></li>
        </ol>
      </nav>
    </div>
  </header>
  <div class="body flex-grow-1 px-3" style="background-color: #06d6a0;"><br>
    <div class="container-lg">
      <div class="card mb-4">
        <div class="card-header">
          <strong>Data User</strong>
        </div>
        <div class="card-body">
          <a href="#" style="font-size: 10pt;" class="btn btn-primary" data-toggle="modal" data-target="#tambahData">
            <img src="https://cdn-icons-png.flaticon.com/512/476/476863.png" style="width: 20px;"> Tambah Data
          </a>
          <div class="example">
            <div class="tab-content rounded-bottom">
              <div class="table-responsive" role="tabpanel" id="preview-877">
                <table style="font-size: 10pt;" id="example" class="table">
                  <thead>
                    <tr>
                      <th scope="col">NO</th>
                      <th scope="col">OPSI</th>
                      <th>FOTO</th>
                      <th scope="col">NAMA</th>
                      <th scope="col">USERNAME</th>
                      <th scope="col">EMAIL</th>
                      <th>NO TELP</th>
                    </tr>
                  </thead>  
                  <?php 
                  $no=1;
                  $user=mysqli_query($koneksi,"SELECT * FROM user ORDER BY nama ASC");
                  while ($row_user=mysqli_fetch_array($user)) {
                    ?>
                    <tr>
                      <td><?= $no++; ?>.</td>
                      <td>
                        <a href="user.php?aksi=del&aqsw=<?= $row_user['id_user']; ?>" onclick="return confirm('Ingin hapus user ini ?')"><img src="https://cdn-icons-png.flaticon.com/512/5028/5028066.png" style="width: 30px;"></a>
                      </td>
                      <td>
                        <?php 
                        if ($row_user['photo']=="") {
                         ?>
                         <img width="50" src="assets/img/user.png">
                       <?php }else{ ?>
                        <img width="50" src="assets/img/<?= $row_user['photo']; ?>">
                      <?php } ?>
                    </td>
                    <td><?= $row_user['nama']; ?></td>
                    <td><?= $row_user['username']; ?></td>
                    <td><?= $row_user['email']; ?></td>
                    <td><?= $row_user['no_telp']; ?></td>
                  </tr>
                <?php } ?>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
</div>

<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Tambah Data User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="" method="post" enctype="multipart/form-data">
        <div class="modal-body">
          <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" placeholder="Nama" class="form-control form-control-sm is-valid" required>
          </div>
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Username" class="form-control form-control-sm is-valid" required>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Masukan Password" class="form-control form-control-sm is-valid" required>
          </div>
          <div class="form-group">
            <label>Jenis Kelamin</label>
            <select class="form-control form-control-sm is-valid" name="id_jk" required>
              <option value="">--Pilih--</option>
              <option value="1">Laki-laki</option>
              <option value="2">Perempuan</option>
            </select>
          </div>
          <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" placeholder="Email aktif" class="form-control form-control-sm is-valid">
          </div>
          <div class="form-group">
            <label>No Telp</label>
            <input type="number" maxlength="12" minlength="12" name="no_telp" placeholder="No Telp" class="form-control form-control-sm is-valid" required>
          </div>  
          <div class="form-group">
            <label>Foto (Jika ada)</label>
            <input type="file" name="photo" class="form-control form-control-sm is-valid">
          </div>  
        </div>
        <div class="modal-footer">
          <button type="submit" name="simpan" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script src="js/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
<script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
<script src="vendors/simplebar/js/simplebar.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    $('#example').DataTable();
  } );
</script>
</body>
</html>