<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
	header("location: login.php");
}
include"../config/koneksi.php";
function formatTanggal($date){
 // ubah string menjadi format tanggal
	return date('d-M-Y', strtotime($date));
}
$dari_tgl=$_POST['dari_tgl'];
$sampai_tgl=$_POST['sampai_tgl'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laporan Data Pasien <?= formatTanggal($dari_tgl); ?> sampai <?= formatTanggal($sampai_tgl); ?></title>
	<link rel="icon" type="image/png" sizes="192x192" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/img/clinic.png">
	<style type="text/css">
		@media print{@page {size: landscape}}
		.page {
			min-height: 210mm;
			width: 297mm;
			margin: auto;
			font-family: "Times New Roman", Times, serif;
			font-size: 10pt;
		}
	</style>
</head>
<body>
	<div class="page">
		<center>
			<h3>Laporan Data Pasien <?= formatTanggal($dari_tgl); ?> sampai <?= formatTanggal($sampai_tgl); ?></h3>
		</center>
		<table width="100%" border="1" style="border-collapse: collapse;">
			<tr>
				<th scope="col">ID PASIEN</th>
				<th scope="col">TGL TERDAFTAR</th>
				<th scope="col">NAMA PASIEN</th>
				<th scope="col">ALAMAT</th>
				<th scope="col">USIA</th>
				<th scope="col">JK</th>
				<th scope="col">NAMA IBU KANDUNG</th>
				<th scope="col">AGAMA</th>
				<th scope="col">NO TELP</th>
				<th scope="col">GOL DARAH</th>
				<th scope="col">PEKERJAAN</th>
			</tr>
			<?php 
			$pasien=mysqli_query($koneksi,"SELECT * FROM tbl_pasien
				INNER JOIN tbl_jk ON tbl_pasien.id_jk=tbl_jk.id_jk
				INNER JOIN tbl_agama ON tbl_pasien.id_agama=tbl_agama.id_agama WHERE tgl_terdaftar BETWEEN '$dari_tgl' AND '$sampai_tgl' ORDER BY tbl_pasien.tgl_terdaftar DESC");
			while ($row_pasien=mysqli_fetch_array($pasien)) {
				?>
				<tr>
					<td style="text-align: center;"><?= $row_pasien['id_pasien']; ?></td>
					<td><?= formatTanggal($row_pasien['tgl_terdaftar']); ?></td>
					<td><span style="font-size: 10pt;" class="badge bg-success"><?= $row_pasien['nama_pasien']; ?></span></td>
					<td><?= $row_pasien['alamat']; ?></td>
					<td style="text-align: center;"><?= $row_pasien['usia']; ?></td>
					<td><?= $row_pasien['jenis_kelamin']; ?></td>
					<td><?= $row_pasien['nama_ibu']; ?></td>
					<td><?= $row_pasien['agama']; ?></td>
					<td><?= $row_pasien['no_telp']; ?></td>
					<td style="text-align: center;"><?= $row_pasien['gol_darah']; ?></td>
					<td><?= $row_pasien['pekerjaan']; ?></td>
				</tr>
			<?php } ?>
		</table>
	</div>
	<script type="text/javascript">
		window.print();
	</script>
</body>
</html>