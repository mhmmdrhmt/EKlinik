<?php 
session_start();
include"../config/koneksi.php";
if (isset($_SESSION["id_user"])) {
  header("location: index.php");
}
$row_pengaturan=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM pengaturan WHERE id_pengaturan=1"));
if (isset($_POST['login'])) {
  $username=mysqli_real_escape_string($koneksi, $_POST['username']);
  $password=mysqli_real_escape_string($koneksi, md5($_POST['password']));
  $cek_data=mysqli_num_rows(mysqli_query($koneksi,"SELECT * FROM user WHERE username='$username' AND password='$password'"));
  if ($cek_data==1) {
    $data_user=mysqli_fetch_array(mysqli_query($koneksi,"SELECT * FROM user WHERE username='$username' AND password='$password'"));
    $_SESSION['id_user']=$data_user['id_user'];
    $_SESSION['nama']=$data_user['nama'];
    $_SESSION['username']=$data_user['username'];
    $_SESSION['id_jk']=$data_user['id_jk'];
    $_SESSION['photo']=$data_user['photo'];
    header("location: index.php");
  }else{
    echo "<script>window.alert('Anda Gagal Masuk')
    window.location='login.php'</script>";
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <base href="./">
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
  <meta name="description" content="E-KLINIK">
  <meta name="author" content="Jevi Alvenosa">
  <meta name="keyword" content="Bootstrap,Admin,Template,Open,Source,jQuery,CSS,HTML,RWD,Dashboard">
  <title>E-KLINIK</title>
  <link rel="icon" type="image/png" sizes="192x192" href="assets/img/clinic.png">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/img/clinic.png">
  <link rel="icon" type="image/png" sizes="96x96" href="assets/img/clinic.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/img/clinic.png">
  <link rel="manifest" href="assets/favicon/manifest.json">
  <meta name="msapplication-TileColor" content="#ffffff">
  <meta name="msapplication-TileImage" content="assets/img/clinic.png">
  <meta name="theme-color" content="#ffffff">
  <!-- Vendors styles-->
  <link rel="stylesheet" href="vendors/simplebar/css/simplebar.css">
  <link rel="stylesheet" href="css/vendors/simplebar.css">
  <!-- Main styles for this application-->
  <link href="css/style.css" rel="stylesheet">
  <!-- We use those styles to show code examples, you should remove them in your application.-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1.23.0/themes/prism.css">
  <link href="css/examples.css" rel="stylesheet">
  <!-- Global site tag (gtag.js) - Google Analytics-->
  <script async="" src="https://www.googletagmanager.com/gtag/js?id=UA-118965717-3"></script>
  <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());
      // Shared ID
      gtag('config', 'UA-118965717-3');
      // Bootstrap ID
      gtag('config', 'UA-118965717-5');
    </script>
  </head>
  <body>
    <div style="background-image: url('assets/img/<?= $row_pengaturan['bg_login']; ?>'); background-size: cover; background-repeat: no-repeat;" class="bg-light min-vh-100 d-flex flex-row align-items-center">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-4">
            <div class="card-group d-block d-md-flex row">
              <div class="card col-md-7 p-4 mb-0">
                <div class="card-body">

                  <form action="" method="post">
                    <h1><img style="width: 100px;" src="assets/img/<?= $row_pengaturan['logo']; ?>">E-KLINIK</h1>
                    <p class="text-medium-emphasis">Masuk menggunakan akun anda</p>
                    <div class="input-group mb-3"><span class="input-group-text">
                      <svg class="icon">
                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-user"></use>
                      </svg></span>
                      <input class="form-control" name="username" autocomplete="off" type="text" placeholder="Username" required>
                    </div>
                    <div class="input-group mb-4"><span class="input-group-text">
                      <svg class="icon">
                        <use xlink:href="vendors/@coreui/icons/svg/free.svg#cil-lock-locked"></use>
                      </svg></span>
                      <input class="form-control" name="password" type="password" placeholder="Password" required>
                    </div>
                    <div class="row">
                      <div class="col-12">
                        <button style="width: 100%;" class="btn btn-info text-white px-4" name="login" type="submit">Masuk</button>
                      </div>
                      <br><br><br>
                      <center>
                        <p><?= $row_pengaturan['copyright']; ?></p>
                      </center>
                      
                    </div>
                  </form>
                  
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- CoreUI and necessary plugins-->
    <script src="vendors/@coreui/coreui/js/coreui.bundle.min.js"></script>
    <script src="vendors/simplebar/js/simplebar.min.js"></script>
    <script>
    </script>

  </body>
  </html>