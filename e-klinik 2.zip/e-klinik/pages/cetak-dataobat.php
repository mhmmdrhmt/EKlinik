<?php 
session_start();
if (!isset($_SESSION["id_user"])) {
	header("location: login.php");
}
include"../config/koneksi.php";
function formatTanggal($date){
 // ubah string menjadi format tanggal
	return date('d-M-Y', strtotime($date));
}
function rupiah($angka){
	$hasil_rupiah = "Rp. " . number_format($angka, 0, ".", ".");
	return $hasil_rupiah;
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Laporan Data Obat</title>
	<link rel="icon" type="image/png" sizes="192x192" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="32x32" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="96x96" href="assets/img/clinic.png">
	<link rel="icon" type="image/png" sizes="16x16" href="assets/img/clinic.png">
	<style type="text/css">
		@media print{@page {size: landscape}}
		.page {
			min-height: 210mm;
			width: 297mm;
			margin: auto;
			font-family: "Times New Roman", Times, serif;
			font-size: 10pt;
		}
	</style>
</head>
<body>
	<div class="page">
		<center>
			<h3>Laporan Data Obat</h3>
		</center>
		<table width="100%" border="1" cellpadding="0" cellspacing="0" style="border-collapse: collapse;">
			<tr>
				<th scope="col">ID OBAT</th>
				<th scope="col">NAMA OBAT</th>
				<th scope="col">JENIS OBAT</th>
				<th scope="col">DOSIS</th>
				<th scope="col">STOCK OBAT</th>
				<th scope="col">STOCK KELUAR</th>
				<th scope="col">TANGGAL KADALUARSA</th>
				<th>HARGA</th>
				<th>HARGA JUAL</th>
				<th>PROFIT</th>
			</tr>
			<?php 
			$obat=mysqli_query($koneksi,"SELECT * FROM tbl_obat ORDER BY nama_obat ASC");
			while ($row_obat=mysqli_fetch_array($obat)) {
				?>
				<tr>
					<td align="center"><?= $row_obat['id_obat']; ?></td>
					<td><?= $row_obat['nama_obat']; ?></td>
					<td><span style="font-size: 10pt;" class="badge bg-info"><?= $row_obat['jenis_obat']; ?></span></td>
					<td align="center"><?= $row_obat['dosis']; ?></td>
					<td align="center"><?= $row_obat['stok_obat']; ?></td>
					<td align="center"><?= $row_obat['stok_keluar']; ?></td>
					<td align="center"><?= formatTanggal($row_obat['tgl_kadaluarsa']); ?></td>
					<td align="center"><?= rupiah($row_obat['harga']); ?></td>
					<td align="center"><?= rupiah($row_obat['harga_jual']); ?></td>
					<td align="center"><?= rupiah($row_obat['profit']); ?></td>
				</tr>
			<?php } ?>
		</table>
	</div>
	<script type="text/javascript">
		window.print();
	</script>
</body>
</html>